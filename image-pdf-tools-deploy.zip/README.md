# 예금/적금 금리 랭킹 대시보드 (한국 은행)

한국 은행/저축은행 예금·적금을 금리 높은 순으로 보여주는 웹사이트입니다.
데이터는 금감원 금융상품한눈에(OpenAPI) 기준으로 배치 수집하고, 화면은 최신 스냅샷을 실시간 조회합니다.

## 핵심 기능
- 예금/적금 탭 전환
- 최고 금리/기본 금리/기관명/상품명 정렬
- 기관명/상품명 검색
- 기관 링크 + 상품 링크(기관 페이지) 제공
- 배치 상태 표시(마지막 배치, 다음 배치, 소스, 건수)
- 배치 즉시 실행 버튼 (`POST /api/batch/run`)
- 30초 간격 자동 새로고침

## 배치 동작
- 서버 시작 시 1회 즉시 실행
- 이후 매일 1회 실행 (KST 기준 시각 설정)
- 기본값: 매일 06:05 KST

## 실행 방법
1. 의존성 설치
```bash
npm install
```

2. 환경 변수 준비
```bash
cp .env.example .env
```

3. `.env` 설정
```env
PORT=3000
FINLIFE_API_KEY=발급받은키
FINLIFE_BASE_URL=https://finlife.fss.or.kr/finlifeapi
FINLIFE_TOP_GROUP_CODES=020000
BATCH_HOUR_KST=6
BATCH_MINUTE_KST=5
```

4. 실행
```bash
npm start
```

5. 접속
- `http://localhost:3000`

## 실제 데이터 연동 주의
- `FINLIFE_API_KEY` 미설정 시 샘플 데이터로 동작합니다.
- 키 설정 시 실데이터 소스가 `실데이터 (finlife.fss.or.kr)`로 표시됩니다.

## API
- `GET /api/health`
- `GET /api/batch/status`
- `POST /api/batch/run`
- `GET /api/rates?type=deposit|savings&sort=maxRate|baseRate|institution|productName&order=asc|desc&q=&limit=100`
