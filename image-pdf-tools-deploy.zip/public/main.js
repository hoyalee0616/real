const TARGET_BYTES = 2 * 1024 * 1024;

const elements = {
  modeCompress: document.getElementById('mode-compress'),
  modeTransparent: document.getElementById('mode-transparent'),
  modePdf: document.getElementById('mode-pdf'),
  heroSub: document.getElementById('hero-sub'),

  imageUploader: document.getElementById('image-uploader'),
  fileInput: document.getElementById('file-input'),
  dropzone: document.getElementById('dropzone'),
  compressControls: document.getElementById('compress-controls'),
  transparentControls: document.getElementById('transparent-controls'),
  compressFormat: document.getElementById('compress-format'),
  transparentFormat: document.getElementById('transparent-format'),
  transparentMethod: document.getElementById('transparent-method'),
  transparentMode: document.getElementById('transparent-mode'),
  transparentColor: document.getElementById('transparent-color'),
  transparentTolerance: document.getElementById('transparent-tolerance'),
  compressButton: document.getElementById('compress-btn'),
  transparentButton: document.getElementById('transparent-btn'),
  imageBatchResults: document.getElementById('image-batch-results'),

  pdfUploader: document.getElementById('pdf-uploader'),
  pdfFile: document.getElementById('pdf-file'),
  pdfPage: document.getElementById('pdf-page'),
  pdfX: document.getElementById('pdf-x'),
  pdfY: document.getElementById('pdf-y'),
  pdfFontSize: document.getElementById('pdf-font-size'),
  pdfText: document.getElementById('pdf-text'),
  pdfAddButton: document.getElementById('pdf-add-btn'),
  pdfItems: document.getElementById('pdf-items'),
  pdfCanvas: document.getElementById('pdf-canvas'),
  pdfSelection: document.getElementById('pdf-selection'),
  pdfSignButton: document.getElementById('pdf-sign-btn'),

  message: document.getElementById('message'),
  result: document.getElementById('result'),
  originalMeta: document.getElementById('original-meta'),
  compressedMeta: document.getElementById('compressed-meta'),
  savedMeta: document.getElementById('saved-meta'),
  previewWrap: document.getElementById('preview-wrap'),
  preview: document.getElementById('preview'),
  downloadLink: document.getElementById('download-link')
};

const state = {
  mode: 'compress',
  imageFiles: [],
  previewUrl: null,
  batchUrls: [],
  aiRemoveBackgroundFn: null,

  pdfFile: null,
  pdfArrayBuffer: null,
  pdfPageCount: 0,
  pdfPreviewDoc: null,
  pdfScale: 1,
  pdfBoxWidth: null,
  pdfSelecting: false,
  pdfDragStart: null,
  pdfBaseImageData: null,
  pdfItems: []
};

function formatBytes(bytes) {
  const mb = bytes / (1024 * 1024);
  if (mb >= 1) return `${mb.toFixed(2)}MB`;
  return `${(bytes / 1024).toFixed(1)}KB`;
}

function setMessage(text, isError = false) {
  elements.message.textContent = text;
  elements.message.classList.toggle('error', isError);
}

function outputExtension(type) {
  if (type === 'image/png') return 'png';
  if (type === 'image/webp') return 'webp';
  if (type === 'application/pdf') return 'pdf';
  return 'jpg';
}

function hexToRgb(hex) {
  const normalized = hex.replace('#', '');
  const full = normalized.length === 3
    ? normalized.split('').map((c) => `${c}${c}`).join('')
    : normalized;

  return {
    r: Number.parseInt(full.slice(0, 2), 16),
    g: Number.parseInt(full.slice(2, 4), 16),
    b: Number.parseInt(full.slice(4, 6), 16)
  };
}

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('파일을 읽을 수 없습니다.'));
    reader.onload = () => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('이미지 파일 형식이 올바르지 않습니다.'));
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

function canvasToBlob(canvas, type, quality) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (!blob) {
        reject(new Error('결과 파일 생성에 실패했습니다.'));
        return;
      }
      resolve(blob);
    }, type, quality);
  });
}

function buildCanvasFromImage(image) {
  const canvas = document.createElement('canvas');
  canvas.width = image.naturalWidth;
  canvas.height = image.naturalHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
  return { canvas, ctx };
}

function sampleCornerColor(ctx, width, height) {
  const points = [
    [0, 0],
    [Math.max(width - 1, 0), 0],
    [0, Math.max(height - 1, 0)],
    [Math.max(width - 1, 0), Math.max(height - 1, 0)]
  ];
  const total = { r: 0, g: 0, b: 0 };

  points.forEach(([x, y]) => {
    const pixel = ctx.getImageData(x, y, 1, 1).data;
    total.r += pixel[0];
    total.g += pixel[1];
    total.b += pixel[2];
  });

  return {
    r: Math.round(total.r / points.length),
    g: Math.round(total.g / points.length),
    b: Math.round(total.b / points.length)
  };
}

function applyBackgroundTransparency(ctx, width, height, color, tolerance) {
  const imageData = ctx.getImageData(0, 0, width, height);
  const pixels = imageData.data;
  let transparentCount = 0;

  for (let i = 0; i < pixels.length; i += 4) {
    const dr = pixels[i] - color.r;
    const dg = pixels[i + 1] - color.g;
    const db = pixels[i + 2] - color.b;
    const distance = Math.sqrt((dr * dr) + (dg * dg) + (db * db));

    if (distance <= tolerance) {
      pixels[i + 3] = 0;
      transparentCount += 1;
    }
  }

  ctx.putImageData(imageData, 0, 0);
  return transparentCount;
}

function resolveCompressOutputType(inputType) {
  const selected = elements.compressFormat.value;
  if (selected !== 'auto') return selected;
  if (inputType === 'image/png' || inputType === 'image/webp') return 'image/webp';
  return 'image/jpeg';
}

async function compressUnder2MB(image, outputType) {
  const { canvas } = buildCanvasFromImage(image);

  if (outputType === 'image/png') {
    const blob = await canvasToBlob(canvas, outputType, 1);
    if (blob.size < TARGET_BYTES) return blob;
    throw new Error('PNG 포맷으로는 2MB 미만이 어려울 수 있습니다. WEBP/JPEG를 사용하세요.');
  }

  let low = 0.2;
  let high = 0.95;
  let best = null;

  for (let i = 0; i < 10; i += 1) {
    const quality = (low + high) / 2;
    const blob = await canvasToBlob(canvas, outputType, quality);

    if (blob.size < TARGET_BYTES) {
      best = blob;
      low = quality;
    } else {
      high = quality;
    }
  }

  if (best) return best;

  const fallback = await canvasToBlob(canvas, outputType, 0.15);
  if (fallback.size < TARGET_BYTES) return fallback;

  throw new Error('2MB 미만으로 줄일 수 없습니다.');
}

async function removeBackgroundAlpha(image) {
  const { canvas, ctx } = buildCanvasFromImage(image);
  const color = elements.transparentMode.value === 'auto'
    ? sampleCornerColor(ctx, canvas.width, canvas.height)
    : hexToRgb(elements.transparentColor.value || '#ffffff');
  const tolerance = Number(elements.transparentTolerance.value || 45);
  const outputType = elements.transparentFormat.value;

  const transparentPixels = applyBackgroundTransparency(ctx, canvas.width, canvas.height, color, tolerance);
  const blob = outputType === 'image/webp'
    ? await canvasToBlob(canvas, outputType, 0.95)
    : await canvasToBlob(canvas, outputType, 1);

  return { blob, outputType, transparentPixels };
}

async function getAiBackgroundRemover() {
  if (state.aiRemoveBackgroundFn) return state.aiRemoveBackgroundFn;
  const mod = await import('https://cdn.jsdelivr.net/npm/@imgly/background-removal/+esm');
  const fn = mod.removeBackground || mod.default?.removeBackground;
  if (!fn) throw new Error('AI 배경 제거 모듈 로딩에 실패했습니다.');
  state.aiRemoveBackgroundFn = fn;
  return fn;
}

async function removeBackgroundWithAI(file) {
  const outputType = elements.transparentFormat.value;
  const removeBackground = await getAiBackgroundRemover();
  const modelCandidates = ['large', 'medium'];
  let lastError = null;

  for (const model of modelCandidates) {
    try {
      const rawBlob = await removeBackground(file, {
        model,
        output: {
          format: outputType,
          quality: 1,
          type: 'foreground'
        }
      });
      const refinedBlob = await refineAiMask(rawBlob, outputType);
      return { blob: refinedBlob, outputType };
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError || new Error('AI 배경 제거에 실패했습니다.');
}

function loadImageFromBlob(blob) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('AI 결과 이미지를 읽지 못했습니다.'));
    };
    img.src = url;
  });
}

async function refineAiMask(blob, outputType) {
  const image = await loadImageFromBlob(blob);
  const { canvas, ctx } = buildCanvasFromImage(image);
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const { data } = imageData;
  const width = canvas.width;
  const height = canvas.height;

  // Edge cleanup: remove tiny speckles and reduce bright fringe on semi-transparent pixels.
  for (let y = 1; y < height - 1; y += 1) {
    for (let x = 1; x < width - 1; x += 1) {
      const idx = (y * width + x) * 4;
      let a = data[idx + 3];
      if (a < 6) {
        data[idx + 3] = 0;
        continue;
      }
      if (a > 249) {
        data[idx + 3] = 255;
        continue;
      }

      let strongNeighbors = 0;
      for (let yy = -1; yy <= 1; yy += 1) {
        for (let xx = -1; xx <= 1; xx += 1) {
          if (xx === 0 && yy === 0) continue;
          const nIdx = ((y + yy) * width + (x + xx)) * 4;
          if (data[nIdx + 3] > 40) strongNeighbors += 1;
        }
      }

      if (a < 18 && strongNeighbors <= 1) {
        data[idx + 3] = 0;
        continue;
      }

      const alphaFactor = Math.min(1, a / 220);
      data[idx] = Math.round(data[idx] * alphaFactor);
      data[idx + 1] = Math.round(data[idx + 1] * alphaFactor);
      data[idx + 2] = Math.round(data[idx + 2] * alphaFactor);
    }
  }

  ctx.putImageData(imageData, 0, 0);
  return outputType === 'image/webp'
    ? canvasToBlob(canvas, outputType, 1)
    : canvasToBlob(canvas, outputType, 1);
}

function renderResult(fileSize, fromLabel, blob, toLabel, outputType, opts = {}) {
  const ratio = ((1 - blob.size / fileSize) * 100).toFixed(1);
  const objectUrl = URL.createObjectURL(blob);
  if (state.previewUrl) URL.revokeObjectURL(state.previewUrl);
  state.previewUrl = objectUrl;

  elements.result.hidden = false;
  elements.originalMeta.textContent = fromLabel;
  elements.compressedMeta.textContent = toLabel;
  elements.savedMeta.textContent = Number.isFinite(Number(ratio))
    ? (blob.size <= fileSize ? `${ratio}% 감소` : `${Math.abs(Number(ratio)).toFixed(1)}% 증가`)
    : '-';

  elements.previewWrap.hidden = !opts.showPreview;
  if (opts.showPreview) elements.preview.src = objectUrl;

  elements.downloadLink.href = objectUrl;
  elements.downloadLink.download = opts.downloadName || `result.${outputExtension(outputType)}`;
}

function clearBatchDownloadList() {
  state.batchUrls.forEach((url) => URL.revokeObjectURL(url));
  state.batchUrls = [];
  elements.imageBatchResults.innerHTML = '';
}

function renderBatchDownloadList(items) {
  if (!items.length) {
    elements.imageBatchResults.innerHTML = '';
    return;
  }

  elements.imageBatchResults.innerHTML = items.map((item) => {
    const url = URL.createObjectURL(item.blob);
    state.batchUrls.push(url);
    return `<div class="pdf-item"><span>${item.name} (${formatBytes(item.blob.size)})</span><a class="btn btn-mini" href="${url}" download="${item.name}">다운로드</a></div>`;
  }).join('');
}

function ensurePdfJsReady() {
  const pdfjsLib = window.pdfjsLib;
  if (!pdfjsLib) {
    throw new Error('PDF 미리보기 라이브러리 로딩 실패: 새로고침 후 다시 시도해 주세요.');
  }

  if (!pdfjsLib.GlobalWorkerOptions.workerSrc) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  }

  return pdfjsLib;
}

function updatePdfActionState() {
  const hasText = Boolean((elements.pdfText.value || '').trim());
  elements.pdfAddButton.disabled = !(state.pdfFile && hasText);
  elements.pdfSignButton.disabled = !(state.pdfFile && state.pdfItems.length > 0);
}

function renderPdfItemsList() {
  if (!state.pdfItems.length) {
    elements.pdfItems.innerHTML = '<p class="hint">추가된 텍스트 박스가 없습니다.</p>';
    return;
  }

  elements.pdfItems.innerHTML = state.pdfItems.map((item, index) => {
    const preview = item.text.length > 24 ? `${item.text.slice(0, 24)}...` : item.text;
    return `<div class="pdf-item" data-id="${item.id}">
      <span>${index + 1}. p${item.page} (${item.x}, ${item.y}) ${preview.replace(/</g, '&lt;')}</span>
      <button class="btn btn-mini" type="button" data-remove-id="${item.id}">삭제</button>
    </div>`;
  }).join('');
}

function clearPdfSelection() {
  state.pdfBoxWidth = null;
  state.pdfSelecting = false;
  state.pdfDragStart = null;
  elements.pdfSelection.hidden = true;
}

function splitLinesForWidth(ctx, line, maxWidth) {
  if (!maxWidth || maxWidth <= 0) return [line];
  const words = line.split(/\s+/);
  const out = [];
  let current = '';

  words.forEach((word) => {
    const next = current ? `${current} ${word}` : word;
    if (!current || ctx.measureText(next).width <= maxWidth) {
      current = next;
      return;
    }
    out.push(current);
    current = word;
  });

  if (current) out.push(current);
  return out.length ? out : [''];
}

function drawTextAt(ctx, text, x, y, fontSize, maxWidth, color = '#111111') {
  const lineHeight = fontSize * 1.2;
  ctx.save();
  ctx.font = `${fontSize}px sans-serif`;
  ctx.fillStyle = color;
  ctx.textBaseline = 'alphabetic';

  let drawY = y;
  text.split('\n').forEach((rawLine) => {
    const lines = splitLinesForWidth(ctx, rawLine, maxWidth);
    lines.forEach((line) => {
      ctx.fillText(line, x, drawY);
      drawY += lineHeight;
    });
  });
  ctx.restore();
}

function drawPdfTextOverlay() {
  if (!state.pdfBaseImageData) return;

  const canvas = elements.pdfCanvas;
  const ctx = canvas.getContext('2d');
  ctx.putImageData(state.pdfBaseImageData, 0, 0);

  const pageNumber = Number(elements.pdfPage.value || 1);
  state.pdfItems
    .filter((item) => item.page === pageNumber)
    .forEach((item) => {
      drawTextAt(
        ctx,
        item.text,
        item.x * state.pdfScale,
        canvas.height - (item.y * state.pdfScale),
        item.fontSize * state.pdfScale,
        item.maxWidth ? item.maxWidth * state.pdfScale : null,
        '#111111'
      );
    });

  const draftText = (elements.pdfText.value || '').trim();
  if (!draftText) return;

  drawTextAt(
    ctx,
    draftText,
    Number(elements.pdfX.value || 0) * state.pdfScale,
    canvas.height - (Number(elements.pdfY.value || 0) * state.pdfScale),
    Math.max(8, Number(elements.pdfFontSize.value || 18)) * state.pdfScale,
    state.pdfBoxWidth ? state.pdfBoxWidth * state.pdfScale : null
  );
}

function updateSelectionVisual(left, top, width, height) {
  elements.pdfSelection.hidden = false;
  elements.pdfSelection.style.left = `${left}px`;
  elements.pdfSelection.style.top = `${top}px`;
  elements.pdfSelection.style.width = `${width}px`;
  elements.pdfSelection.style.height = `${height}px`;
}

function getCanvasPoint(event) {
  const rect = elements.pdfCanvas.getBoundingClientRect();
  const scaleX = elements.pdfCanvas.width / rect.width;
  const scaleY = elements.pdfCanvas.height / rect.height;
  const x = (event.clientX - rect.left) * scaleX;
  const y = (event.clientY - rect.top) * scaleY;
  return {
    x: Math.max(0, Math.min(elements.pdfCanvas.width, x)),
    y: Math.max(0, Math.min(elements.pdfCanvas.height, y))
  };
}

async function renderPdfPage(pageNumber, options = {}) {
  if (!state.pdfArrayBuffer) return;

  const pdfjsLib = ensurePdfJsReady();
  if (!state.pdfPreviewDoc) {
    const loadingTask = pdfjsLib.getDocument({
      data: new Uint8Array(state.pdfArrayBuffer.slice(0))
    });
    state.pdfPreviewDoc = await loadingTask.promise;
  }

  const validPage = Math.max(1, Math.min(pageNumber, state.pdfPreviewDoc.numPages));
  elements.pdfPage.value = String(validPage);

  const page = await state.pdfPreviewDoc.getPage(validPage);
  const viewport = page.getViewport({ scale: state.pdfScale });
  const canvas = elements.pdfCanvas;
  const ctx = canvas.getContext('2d');
  canvas.width = Math.floor(viewport.width);
  canvas.height = Math.floor(viewport.height);

  await page.render({ canvasContext: ctx, viewport }).promise;
  state.pdfBaseImageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  if (!options.keepSelection) clearPdfSelection();
  drawPdfTextOverlay();
}

async function loadPdfMeta(file) {
  const { PDFDocument } = window.PDFLib || {};
  if (!PDFDocument) throw new Error('PDF 기능 로딩 실패: 페이지를 새로고침해 주세요.');

  const arrayBuffer = await file.arrayBuffer();
  const doc = await PDFDocument.load(new Uint8Array(arrayBuffer.slice(0)));
  return { pages: doc.getPageCount(), arrayBuffer };
}

async function writeTextToPdf() {
  const { PDFDocument, StandardFonts, rgb } = window.PDFLib || {};
  if (!PDFDocument) throw new Error('PDF 기능 로딩 실패: 페이지를 새로고침해 주세요.');
  if (!state.pdfArrayBuffer || !state.pdfFile) throw new Error('PDF 파일을 선택해 주세요.');

  const pdfDoc = await PDFDocument.load(new Uint8Array(state.pdfArrayBuffer.slice(0)));
  const pageCount = pdfDoc.getPageCount();
  if (!state.pdfItems.length) throw new Error('텍스트 박스를 먼저 추가해 주세요.');
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);

  state.pdfItems.forEach((item) => {
    if (!Number.isInteger(item.page) || item.page < 1 || item.page > pageCount) return;
    const page = pdfDoc.getPage(item.page - 1);
    const drawOptions = {
      x: item.x,
      y: item.y,
      size: item.fontSize,
      font,
      color: rgb(0, 0, 0),
      lineHeight: item.fontSize * 1.2
    };

    if (item.maxWidth && Number.isFinite(item.maxWidth) && item.maxWidth > 0) {
      drawOptions.maxWidth = item.maxWidth;
    }
    page.drawText(item.text, drawOptions);
  });

  const output = await pdfDoc.save();
  return {
    blob: new Blob([output], { type: 'application/pdf' }),
    pages: pageCount
  };
}

function onImageFilesSelected(files) {
  const list = Array.from(files || []);
  if (!list.length) return;
  if (list.some((file) => !file.type.startsWith('image/'))) {
    setMessage('이미지 파일만 업로드할 수 있습니다.', true);
    return;
  }

  state.imageFiles = list;
  elements.result.hidden = true;
  clearBatchDownloadList();
  elements.compressButton.disabled = false;
  elements.transparentButton.disabled = false;
  const totalBytes = list.reduce((sum, file) => sum + file.size, 0);
  setMessage(`${list.length}개 선택됨 (${formatBytes(totalBytes)})`);
}

async function onPdfFileSelected(file) {
  state.pdfFile = null;
  state.pdfArrayBuffer = null;
  state.pdfPageCount = 0;
  state.pdfPreviewDoc = null;
  state.pdfBaseImageData = null;
  state.pdfItems = [];
  elements.pdfSignButton.disabled = true;
  clearPdfSelection();
  renderPdfItemsList();

  const ctx = elements.pdfCanvas.getContext('2d');
  ctx.clearRect(0, 0, elements.pdfCanvas.width, elements.pdfCanvas.height);

  if (!file) return;

  if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    setMessage('PDF 파일만 업로드할 수 있습니다.', true);
    return;
  }

  try {
    const meta = await loadPdfMeta(file);
    state.pdfFile = file;
    state.pdfArrayBuffer = meta.arrayBuffer;
    state.pdfPageCount = meta.pages;

    elements.pdfPage.max = String(meta.pages);
    elements.pdfPage.value = '1';

    await renderPdfPage(1);
    renderPdfItemsList();
    updatePdfActionState();
    setMessage(`PDF 선택됨: ${file.name} (${meta.pages}페이지)`);
  } catch (error) {
    setMessage(`PDF 읽기 실패: ${error.message}`, true);
  }
}

function setMode(nextMode) {
  state.mode = nextMode;

  elements.modeCompress.classList.toggle('active', nextMode === 'compress');
  elements.modeTransparent.classList.toggle('active', nextMode === 'transparent');
  elements.modePdf.classList.toggle('active', nextMode === 'pdf');

  const isPdf = nextMode === 'pdf';
  const isCompress = nextMode === 'compress';

  elements.imageUploader.hidden = isPdf;
  elements.pdfUploader.hidden = !isPdf;
  elements.compressControls.hidden = !isCompress;
  elements.transparentControls.hidden = nextMode !== 'transparent';

  if (isCompress) {
    elements.heroSub.textContent = '원본 해상도(가로/세로)는 그대로 유지하고, 파일 크기만 2MB 미만으로 압축합니다.';
    setMessage('이미지를 선택하면 압축 준비가 됩니다.');
    return;
  }

  if (nextMode === 'transparent') {
    elements.heroSub.textContent = '이미지를 넣으면 배경색 영역을 알파 처리해서 투명 배경 파일로 만듭니다.';
    setMessage('이미지를 선택하면 배경 투명화 준비가 됩니다.');
    return;
  }

  elements.heroSub.textContent = 'PDF를 열고 영역을 드래그로 선택한 뒤 텍스트를 입력하면 선택한 위치/폭으로 바로 삽입할 수 있습니다.';
  setMessage('PDF 파일을 선택해 주세요.');
}

async function runCompress() {
  if (!state.imageFiles.length) return;
  elements.compressButton.disabled = true;
  elements.transparentButton.disabled = true;
  clearBatchDownloadList();
  setMessage(`압축 중입니다... (0/${state.imageFiles.length})`);

  try {
    const outputs = [];

    for (let i = 0; i < state.imageFiles.length; i += 1) {
      const file = state.imageFiles[i];
      setMessage(`압축 중입니다... (${i + 1}/${state.imageFiles.length}) ${file.name}`);
      const image = await loadImage(file);
      const outputType = resolveCompressOutputType(file.type);
      const blob = await compressUnder2MB(image, outputType);
      const baseName = file.name.replace(/\.[^/.]+$/, '');
      const downloadName = `${baseName}-under-2mb.${outputExtension(outputType)}`;
      outputs.push({ name: downloadName, blob, file, image, outputType });
    }

    const first = outputs[0];
    const fromLabel = `${formatBytes(first.file.size)} / ${first.image.naturalWidth}x${first.image.naturalHeight}`;
    const toLabel = `${formatBytes(first.blob.size)} / ${first.image.naturalWidth}x${first.image.naturalHeight}`;
    renderResult(first.file.size, fromLabel, first.blob, toLabel, first.outputType, {
      showPreview: true,
      downloadName: first.name
    });
    renderBatchDownloadList(outputs.map(({ name, blob }) => ({ name, blob })));
    setMessage(`완료: ${outputs.length}개 이미지 압축 성공`);
  } catch (error) {
    elements.result.hidden = true;
    setMessage(error.message, true);
  } finally {
    elements.compressButton.disabled = false;
    elements.transparentButton.disabled = false;
  }
}

async function runTransparency() {
  if (!state.imageFiles.length) return;
  elements.transparentButton.disabled = true;
  elements.compressButton.disabled = true;
  clearBatchDownloadList();
  setMessage(`배경 투명화 처리 중입니다... (0/${state.imageFiles.length})`);

  try {
    const method = elements.transparentMethod.value;
    const outputs = [];
    let totalTransparentPixels = 0;

    if (method === 'ai') {
      setMessage('고품질 AI 배경 제거 중입니다... (처음 1회 모델 다운로드가 있으며, 이미지는 서버에 업로드되지 않습니다)');
    }

    for (let i = 0; i < state.imageFiles.length; i += 1) {
      const file = state.imageFiles[i];
      setMessage(`배경 투명화 처리 중입니다... (${i + 1}/${state.imageFiles.length}) ${file.name}`);
      let blob;
      let outputType;
      let image;

      if (method === 'ai') {
        const aiResult = await removeBackgroundWithAI(file);
        blob = aiResult.blob;
        outputType = aiResult.outputType;
        image = await loadImage(file);
      } else {
        image = await loadImage(file);
        const colorResult = await removeBackgroundAlpha(image);
        blob = colorResult.blob;
        outputType = colorResult.outputType;
        totalTransparentPixels += colorResult.transparentPixels;
      }

      const baseName = file.name.replace(/\.[^/.]+$/, '');
      outputs.push({
        name: `${baseName}-transparent.${outputExtension(outputType)}`,
        blob,
        file,
        image,
        outputType
      });
    }

    const first = outputs[0];
    const fromLabel = `${formatBytes(first.file.size)} / ${first.image.naturalWidth}x${first.image.naturalHeight}`;
    const toLabel = `${formatBytes(first.blob.size)} / ${first.image.naturalWidth}x${first.image.naturalHeight}`;
    renderResult(first.file.size, fromLabel, first.blob, toLabel, first.outputType, {
      showPreview: true,
      downloadName: first.name
    });
    renderBatchDownloadList(outputs.map(({ name, blob }) => ({ name, blob })));

    if (method === 'ai') {
      setMessage(`완료: AI 배경 제거 ${outputs.length}개 처리 성공`);
      return;
    }

    if (totalTransparentPixels === 0) {
      setMessage('완료: 처리되었지만 투명화된 픽셀이 거의 없습니다. 강도를 높여보세요.');
      return;
    }

    setMessage(`완료: 배경 투명화 ${outputs.length}개 처리 (${totalTransparentPixels.toLocaleString('ko-KR')}px)`);
  } catch (error) {
    elements.result.hidden = true;
    setMessage(`배경 제거 실패: ${error.message}`, true);
  } finally {
    elements.transparentButton.disabled = false;
    elements.compressButton.disabled = false;
  }
}

async function runPdfTextInsert() {
  if (!state.pdfFile || !state.pdfArrayBuffer) return;

  elements.pdfSignButton.disabled = true;
  setMessage('PDF에 텍스트 넣는 중입니다...');

  try {
    const { blob, pages } = await writeTextToPdf();
    const fromLabel = `${formatBytes(state.pdfFile.size)} / ${pages}페이지`;
    const toLabel = `${formatBytes(blob.size)} / ${pages}페이지`;
    const baseName = state.pdfFile.name.replace(/\.[^/.]+$/, '');

    renderResult(state.pdfFile.size, fromLabel, blob, toLabel, 'application/pdf', {
      showPreview: false,
      downloadName: `${baseName}-text.pdf`
    });
    setMessage('완료: 텍스트가 삽입된 PDF 생성 성공');
  } catch (error) {
    elements.result.hidden = true;
    setMessage(error.message, true);
  } finally {
    updatePdfActionState();
  }
}

function addPdfTextItem() {
  if (!state.pdfFile) return;
  const text = (elements.pdfText.value || '').trim();
  if (!text) {
    setMessage('추가할 텍스트를 입력해 주세요.', true);
    return;
  }

  const page = Number(elements.pdfPage.value || 1);
  const x = Number(elements.pdfX.value || 60);
  const y = Number(elements.pdfY.value || 60);
  const fontSize = Number(elements.pdfFontSize.value || 18);
  if (!Number.isInteger(page) || page < 1 || page > state.pdfPageCount) {
    setMessage('페이지 번호를 확인해 주세요.', true);
    return;
  }
  if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(fontSize) || fontSize <= 0) {
    setMessage('좌표/글자 크기 값을 확인해 주세요.', true);
    return;
  }

  state.pdfItems.push({
    id: `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    page,
    text,
    x,
    y,
    fontSize,
    maxWidth: state.pdfBoxWidth
  });

  elements.pdfText.value = '';
  renderPdfItemsList();
  updatePdfActionState();
  drawPdfTextOverlay();
  setMessage(`텍스트 박스 추가됨 (${state.pdfItems.length}개)`);
}

function syncTransparentControls() {
  const isColorMode = elements.transparentMethod.value === 'color';
  elements.transparentMode.disabled = !isColorMode;
  elements.transparentColor.disabled = !isColorMode || elements.transparentMode.value === 'auto';
  elements.transparentTolerance.disabled = !isColorMode;
}

elements.modeCompress.addEventListener('click', () => setMode('compress'));
elements.modeTransparent.addEventListener('click', () => setMode('transparent'));
elements.modePdf.addEventListener('click', () => setMode('pdf'));

elements.fileInput.addEventListener('change', (event) => {
  onImageFilesSelected(event.target.files || []);
});

elements.pdfFile.addEventListener('change', (event) => {
  void onPdfFileSelected(event.target.files?.[0] || null);
});

elements.pdfPage.addEventListener('change', () => {
  if (!state.pdfPreviewDoc) return;
  void renderPdfPage(Number(elements.pdfPage.value || 1));
});

elements.pdfText.addEventListener('input', updatePdfActionState);
elements.pdfText.addEventListener('input', drawPdfTextOverlay);
elements.pdfX.addEventListener('input', drawPdfTextOverlay);
elements.pdfY.addEventListener('input', drawPdfTextOverlay);
elements.pdfFontSize.addEventListener('input', drawPdfTextOverlay);

elements.compressButton.addEventListener('click', () => {
  void runCompress();
});

elements.transparentButton.addEventListener('click', () => {
  void runTransparency();
});

elements.pdfSignButton.addEventListener('click', () => {
  void runPdfTextInsert();
});
elements.pdfAddButton.addEventListener('click', addPdfTextItem);

elements.pdfItems.addEventListener('click', (event) => {
  const target = event.target;
  if (!(target instanceof HTMLElement)) return;
  const removeId = target.dataset.removeId;
  if (!removeId) return;
  state.pdfItems = state.pdfItems.filter((item) => item.id !== removeId);
  renderPdfItemsList();
  updatePdfActionState();
  drawPdfTextOverlay();
  setMessage(`텍스트 박스 삭제됨 (${state.pdfItems.length}개 남음)`);
});

elements.transparentMode.addEventListener('change', syncTransparentControls);
elements.transparentMethod.addEventListener('change', syncTransparentControls);

['dragenter', 'dragover'].forEach((eventName) => {
  elements.dropzone.addEventListener(eventName, (event) => {
    event.preventDefault();
    elements.dropzone.classList.add('dragging');
  });
});

['dragleave', 'drop'].forEach((eventName) => {
  elements.dropzone.addEventListener(eventName, (event) => {
    event.preventDefault();
    elements.dropzone.classList.remove('dragging');
  });
});

elements.dropzone.addEventListener('drop', (event) => {
  const files = event.dataTransfer?.files || [];
  if (!files.length) return;
  onImageFilesSelected(files);
});

elements.pdfCanvas.addEventListener('mousedown', (event) => {
  if (!state.pdfPreviewDoc) return;
  state.pdfSelecting = true;
  state.pdfDragStart = getCanvasPoint(event);
  updateSelectionVisual(state.pdfDragStart.x, state.pdfDragStart.y, 1, 1);
});

elements.pdfCanvas.addEventListener('mousemove', (event) => {
  if (!state.pdfSelecting || !state.pdfDragStart) return;

  const current = getCanvasPoint(event);
  const left = Math.min(state.pdfDragStart.x, current.x);
  const top = Math.min(state.pdfDragStart.y, current.y);
  const width = Math.max(1, Math.abs(current.x - state.pdfDragStart.x));
  const height = Math.max(1, Math.abs(current.y - state.pdfDragStart.y));
  updateSelectionVisual(left, top, width, height);
});

elements.pdfCanvas.addEventListener('mouseup', (event) => {
  if (!state.pdfSelecting || !state.pdfDragStart) return;

  const end = getCanvasPoint(event);
  const left = Math.min(state.pdfDragStart.x, end.x);
  const top = Math.min(state.pdfDragStart.y, end.y);
  const width = Math.max(12, Math.abs(end.x - state.pdfDragStart.x));
  const height = Math.max(12, Math.abs(end.y - state.pdfDragStart.y));
  updateSelectionVisual(left, top, width, height);

  const xPdf = left / state.pdfScale;
  const yPdf = (elements.pdfCanvas.height - (top + height)) / state.pdfScale;
  const boxWidthPdf = width / state.pdfScale;
  const boxHeightPdf = height / state.pdfScale;

  state.pdfBoxWidth = Math.round(boxWidthPdf);
  elements.pdfX.value = String(Math.round(xPdf));
  elements.pdfY.value = String(Math.round(yPdf));
  elements.pdfFontSize.value = String(Math.max(8, Math.round(boxHeightPdf * 0.7)));
  state.pdfSelecting = false;
  state.pdfDragStart = null;
  drawPdfTextOverlay();
  elements.pdfText.focus();
  setMessage(`영역 선택됨: X ${elements.pdfX.value}, Y ${elements.pdfY.value}, 폭 ${state.pdfBoxWidth}`);
});

elements.pdfCanvas.addEventListener('mouseleave', () => {
  if (!state.pdfSelecting) return;
  state.pdfSelecting = false;
  state.pdfDragStart = null;
});

syncTransparentControls();
renderPdfItemsList();
setMode('compress');
