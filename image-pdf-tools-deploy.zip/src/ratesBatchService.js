const fs = require('fs/promises');
const path = require('path');
const axios = require('axios');

const KST_OFFSET_MS = 9 * 60 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;

const DATA_DIR = path.join(__dirname, '..', 'data');
const SNAPSHOT_PATH = path.join(DATA_DIR, 'rates.latest.json');

function toNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function safeText(value, fallback = '') {
  if (typeof value === 'string') {
    const trimmed = value.trim();
    return trimmed || fallback;
  }
  return fallback;
}

function getNextRunAt(hourKst, minuteKst, now = Date.now()) {
  const kstNow = new Date(now + KST_OFFSET_MS);
  const year = kstNow.getUTCFullYear();
  const month = kstNow.getUTCMonth();
  const date = kstNow.getUTCDate();

  const nextKst = Date.UTC(year, month, date, hourKst, minuteKst, 0, 0);
  let nextUtc = nextKst - KST_OFFSET_MS;
  if (nextUtc <= now) nextUtc += DAY_MS;
  return nextUtc;
}

function buildSampleData(nowIso) {
  return [
    {
      id: 'sample-deposit-1',
      type: 'deposit',
      institution: '국민은행(샘플)',
      institutionUrl: 'https://www.kbstar.com',
      productName: 'KB 정기예금',
      productUrl: 'https://finlife.fss.or.kr',
      baseRate: 3.4,
      maxRate: 3.7,
      joinPeriodMonths: 12,
      signupMethod: 'both',
      note: '샘플 데이터',
      updatedAt: nowIso
    },
    {
      id: 'sample-savings-1',
      type: 'savings',
      institution: '신한은행(샘플)',
      institutionUrl: 'https://www.shinhan.com',
      productName: '신한 적금',
      productUrl: 'https://finlife.fss.or.kr',
      baseRate: 3.8,
      maxRate: 5.0,
      joinPeriodMonths: 12,
      signupMethod: 'online',
      note: '샘플 데이터',
      updatedAt: nowIso
    }
  ];
}

class RatesBatchService {
  constructor() {
    this.items = [];
    this.meta = {
      source: 'sample',
      providerName: 'sample',
      lastRunAt: null,
      nextRunAt: null,
      lastDurationMs: null,
      runCount: 0,
      running: false,
      lastError: null
    };
    this.timer = null;
  }

  async init() {
    await this.loadSnapshot();
    await this.runBatch('startup');
    this.scheduleDaily();
  }

  async loadSnapshot() {
    try {
      const raw = await fs.readFile(SNAPSHOT_PATH, 'utf-8');
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed.items)) this.items = parsed.items;
      if (parsed.meta && typeof parsed.meta === 'object') {
        this.meta = { ...this.meta, ...parsed.meta };
      }
    } catch (_err) {
      // first run without snapshot
    }
  }

  async persistSnapshot() {
    await fs.mkdir(DATA_DIR, { recursive: true });
    await fs.writeFile(
      SNAPSHOT_PATH,
      JSON.stringify(
        {
          items: this.items,
          meta: this.meta
        },
        null,
        2
      )
    );
  }

  getFinlifeConfig() {
    return {
      apiKey: safeText(process.env.FINLIFE_API_KEY),
      baseUrl: safeText(process.env.FINLIFE_BASE_URL, 'https://finlife.fss.or.kr/finlifeapi'),
      groupCodes: safeText(process.env.FINLIFE_TOP_GROUP_CODES, '020000').split(',').map((s) => s.trim()).filter(Boolean),
      pageSize: Math.max(1, Math.min(200, toNumber(process.env.FINLIFE_PAGE_SIZE, 100)))
    };
  }

  async fetchFinlifePaged(pathName, groupCode, config) {
    const rows = [];
    let pageNo = 1;
    let maxPage = 1;

    while (pageNo <= maxPage) {
      const response = await axios.get(`${config.baseUrl}/${pathName}`, {
        timeout: 15000,
        params: {
          auth: config.apiKey,
          topFinGrpNo: groupCode,
          pageNo
        }
      });

      const result = response.data?.result || {};
      const errCd = safeText(result.err_cd);
      if (errCd && errCd !== '000') {
        throw new Error(`FINLIFE API 오류(${pathName}/${groupCode}): ${safeText(result.err_msg, errCd)}`);
      }

      const list = Array.isArray(result.baseList) ? result.baseList : [];
      rows.push(...list);
      maxPage = Math.max(1, toNumber(result.max_page_no, 1));
      pageNo += 1;
    }

    return rows;
  }

  async fetchFinlifeProductRows(pathName, groupCode, config) {
    const baseRows = [];
    const optionRows = [];
    let pageNo = 1;
    let maxPage = 1;

    while (pageNo <= maxPage) {
      const response = await axios.get(`${config.baseUrl}/${pathName}`, {
        timeout: 15000,
        params: {
          auth: config.apiKey,
          topFinGrpNo: groupCode,
          pageNo
        }
      });

      const result = response.data?.result || {};
      const errCd = safeText(result.err_cd);
      if (errCd && errCd !== '000') {
        throw new Error(`FINLIFE API 오류(${pathName}/${groupCode}): ${safeText(result.err_msg, errCd)}`);
      }

      if (Array.isArray(result.baseList)) baseRows.push(...result.baseList);
      if (Array.isArray(result.optionList)) optionRows.push(...result.optionList);
      maxPage = Math.max(1, toNumber(result.max_page_no, 1));
      pageNo += 1;
    }

    return { baseRows, optionRows };
  }

  buildOptionMap(optionRows) {
    const map = new Map();

    for (const row of optionRows) {
      const finPrdtCd = safeText(row.fin_prdt_cd);
      const saveTrm = Math.max(1, toNumber(row.save_trm, 12));
      const key = `${finPrdtCd}:${saveTrm}`;
      const baseRate = toNumber(row.intr_rate, 0);
      const maxRate = Math.max(baseRate, toNumber(row.intr_rate2, baseRate));
      const current = map.get(key);
      if (!current || maxRate > current.maxRate) {
        map.set(key, { baseRate, maxRate, saveTrm });
      }
    }

    return map;
  }

  normalizeSignupMethod(joinWay) {
    const text = safeText(joinWay).toLowerCase();
    if (text.includes('인터넷') || text.includes('모바일') || text.includes('스마트')) return 'online';
    if (text.includes('영업점') || text.includes('창구')) return 'offline';
    return 'both';
  }

  normalizeFinlifeRows(type, baseRows, optionRows, companyMap, nowIso) {
    const optionMap = this.buildOptionMap(optionRows);
    const result = [];

    for (const base of baseRows) {
      const finPrdtCd = safeText(base.fin_prdt_cd);
      const preferredTerm = Math.max(1, toNumber(base.save_trm, 12));
      const matched = optionMap.get(`${finPrdtCd}:${preferredTerm}`) || optionMap.get(`${finPrdtCd}:12`);
      const baseRate = matched ? matched.baseRate : toNumber(base.intr_rate, 0);
      const maxRate = matched ? matched.maxRate : Math.max(baseRate, toNumber(base.intr_rate2, baseRate));
      const finCoNo = safeText(base.fin_co_no);
      const institutionUrl = companyMap.get(finCoNo) || 'https://finlife.fss.or.kr';

      result.push({
        id: `${type}-${finCoNo}-${finPrdtCd}`,
        type,
        institution: safeText(base.kor_co_nm, '은행'),
        institutionUrl,
        productName: safeText(base.fin_prdt_nm, '상품명 미상'),
        productUrl: institutionUrl,
        baseRate,
        maxRate,
        joinPeriodMonths: matched ? matched.saveTrm : preferredTerm,
        signupMethod: this.normalizeSignupMethod(base.join_way),
        note: safeText(base.mtrt_int || base.spcl_cnd),
        updatedAt: nowIso
      });
    }

    return result;
  }

  async fetchRatesFromProvider() {
    const nowIso = new Date().toISOString();
    const config = this.getFinlifeConfig();

    if (!config.apiKey) {
      return {
        source: 'sample',
        providerName: 'sample',
        items: buildSampleData(nowIso)
      };
    }

    const companyMap = new Map();
    for (const groupCode of config.groupCodes) {
      const companies = await this.fetchFinlifePaged('companySearch.json', groupCode, config);
      for (const company of companies) {
        const finCoNo = safeText(company.fin_co_no);
        const home = safeText(company.home_url || company.homp_url || company.kor_co_nm);
        const normalizedHome = home.startsWith('http') ? home : (home ? `https://${home}` : '');
        if (finCoNo && normalizedHome) companyMap.set(finCoNo, normalizedHome);
      }
    }

    const depositRows = [];
    const savingsRows = [];
    for (const groupCode of config.groupCodes) {
      const deposit = await this.fetchFinlifeProductRows('depositProductsSearch.json', groupCode, config);
      depositRows.push(...this.normalizeFinlifeRows('deposit', deposit.baseRows, deposit.optionRows, companyMap, nowIso));

      const savings = await this.fetchFinlifeProductRows('savingProductsSearch.json', groupCode, config);
      savingsRows.push(...this.normalizeFinlifeRows('savings', savings.baseRows, savings.optionRows, companyMap, nowIso));
    }

    return {
      source: 'external',
      providerName: 'finlife.fss.or.kr',
      items: [...depositRows, ...savingsRows]
    };
  }

  async runBatch(reason = 'manual') {
    if (this.meta.running) {
      return { ok: false, message: '이미 배치 실행 중입니다.' };
    }

    const startedAt = Date.now();
    this.meta.running = true;
    this.meta.lastError = null;

    try {
      const fetched = await this.fetchRatesFromProvider();
      this.items = fetched.items;
      this.meta.source = fetched.source;
      this.meta.providerName = fetched.providerName;
      this.meta.lastRunAt = new Date().toISOString();
      this.meta.lastDurationMs = Date.now() - startedAt;
      this.meta.runCount += 1;
      this.meta.running = false;
      await this.persistSnapshot();
      return {
        ok: true,
        reason,
        count: this.items.length,
        source: this.meta.source,
        providerName: this.meta.providerName,
        lastRunAt: this.meta.lastRunAt
      };
    } catch (error) {
      this.meta.running = false;
      this.meta.lastError = error.message;
      this.meta.lastDurationMs = Date.now() - startedAt;
      await this.persistSnapshot();
      return { ok: false, reason, message: error.message };
    }
  }

  scheduleDaily() {
    if (this.timer) clearTimeout(this.timer);

    const hourKst = Math.min(23, Math.max(0, toNumber(process.env.BATCH_HOUR_KST, 6)));
    const minuteKst = Math.min(59, Math.max(0, toNumber(process.env.BATCH_MINUTE_KST, 5)));
    const nextRunAt = getNextRunAt(hourKst, minuteKst);
    this.meta.nextRunAt = new Date(nextRunAt).toISOString();

    const delay = Math.max(1000, nextRunAt - Date.now());
    this.timer = setTimeout(async () => {
      await this.runBatch('scheduled-daily');
      this.scheduleDaily();
    }, delay);
  }

  getStatus() {
    return {
      ...this.meta,
      itemCount: this.items.length
    };
  }

  queryRates({ type = 'deposit', sort = 'maxRate', order = 'desc', q = '', limit = 50 }) {
    const safeType = type === 'savings' ? 'savings' : 'deposit';
    const keyword = safeText(q).toLowerCase();
    const safeSort = ['maxRate', 'baseRate', 'institution', 'productName'].includes(sort) ? sort : 'maxRate';
    const safeOrder = order === 'asc' ? 'asc' : 'desc';
    const safeLimit = Math.min(200, Math.max(1, Number(limit) || 50));

    const filtered = this.items.filter((item) => {
      if (item.type !== safeType) return false;
      if (!keyword) return true;
      const haystack = `${item.institution} ${item.productName} ${item.note}`.toLowerCase();
      return haystack.includes(keyword);
    });

    filtered.sort((a, b) => {
      let av = a[safeSort];
      let bv = b[safeSort];
      if (typeof av === 'string') av = av.toLowerCase();
      if (typeof bv === 'string') bv = bv.toLowerCase();
      if (av < bv) return safeOrder === 'asc' ? -1 : 1;
      if (av > bv) return safeOrder === 'asc' ? 1 : -1;
      return 0;
    });

    return filtered.slice(0, safeLimit);
  }
}

module.exports = new RatesBatchService();
