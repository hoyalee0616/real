require('dotenv').config();
const path = require('path');
const express = require('express');
const ratesBatchService = require('./ratesBatchService');

const app = express();
const port = Number(process.env.PORT || 3000);

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, now: new Date().toISOString() });
});

app.get('/api/batch/status', (_req, res) => {
  res.json({
    ok: true,
    status: ratesBatchService.getStatus()
  });
});

app.post('/api/batch/run', async (_req, res) => {
  const result = await ratesBatchService.runBatch('manual-api');
  if (!result.ok) {
    return res.status(500).json(result);
  }
  return res.json(result);
});

app.get('/api/rates', (req, res) => {
  const rows = ratesBatchService.queryRates({
    type: String(req.query.type || 'deposit').toLowerCase(),
    sort: String(req.query.sort || 'maxRate'),
    order: String(req.query.order || 'desc').toLowerCase(),
    q: String(req.query.q || ''),
    limit: String(req.query.limit || '50')
  });

  res.json({
    ok: true,
    rows,
    status: ratesBatchService.getStatus()
  });
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

async function start() {
  await ratesBatchService.init();
  app.listen(port, () => {
    console.log(`Rates dashboard running on http://localhost:${port}`);
  });
}

start().catch((error) => {
  console.error('Failed to start app:', error.message);
  process.exit(1);
});
