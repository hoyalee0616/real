require('dotenv').config();
const path = require('path');
const express = require('express');
const axios = require('axios');
const ratesBatchService = require('./ratesBatchService');

const app = express();
const port = Number(process.env.PORT || 3000);

app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, now: new Date().toISOString() });
});

app.get('/api/batch/status', (_req, res) => {
  res.json({
    ok: true,
    status: ratesBatchService.getStatus()
  });
});

app.post('/api/batch/run', async (_req, res) => {
  const result = await ratesBatchService.runBatch('manual-api');
  if (!result.ok) {
    return res.status(500).json(result);
  }
  return res.json(result);
});

app.get('/api/rates', (req, res) => {
  const rows = ratesBatchService.queryRates({
    type: String(req.query.type || 'deposit').toLowerCase(),
    sort: String(req.query.sort || 'maxRate'),
    order: String(req.query.order || 'desc').toLowerCase(),
    q: String(req.query.q || ''),
    limit: String(req.query.limit || '50')
  });

  res.json({
    ok: true,
    rows,
    status: ratesBatchService.getStatus()
  });
});

const KAKAO_REST_API_KEY = String(process.env.KAKAO_REST_API_KEY || '').trim();
const BUILDING_REGISTRY_SERVICE_KEY = String(process.env.BUILDING_REGISTRY_SERVICE_KEY || '').trim();
const KAKAO_MAP_JS_KEY = String(process.env.KAKAO_MAP_JS_KEY || '').trim();
const MOLIT_RTMS_SERVICE_KEY = String(
  process.env.MOLIT_RTMS_SERVICE_KEY || process.env.BUILDING_REGISTRY_SERVICE_KEY || ''
).trim();
const KAKAO_BASE_URL = 'https://dapi.kakao.com/v2/local';
const BLD_REGISTRY_BASE_URL = 'https://apis.data.go.kr/1613000/BldRgstHubService';
const RTMS_APT_URL = 'https://apis.data.go.kr/1613000/RTMSDataSvcAptTradeDev/getRTMSDataSvcAptTradeDev';
const RTMS_OFFI_URL = 'https://apis.data.go.kr/1613000/RTMSDataSvcOffiTradeDev/getRTMSDataSvcOffiTradeDev';
const REB_APTID_SERVICE_KEY = String(
  process.env.REB_APTID_SERVICE_KEY || process.env.BUILDING_REGISTRY_SERVICE_KEY || ''
).trim();
const REB_APTID_BASE_URL = 'https://api.odcloud.kr/api/AptIdInfoSvc/v1';
const VWORLD_APT_PRICE_KEY = String(process.env.VWORLD_APT_PRICE_KEY || '').trim();
const VWORLD_APT_ATTR_URL = 'https://api.vworld.kr/ned/data/getApartHousingPriceAttr';
const MIN_VALID_AREA_SQM = 10;
const MAX_VALID_AREA_SQM = 400;

app.get('/api/client-config', (_req, res) => {
  res.json({
    ok: true,
    kakaoMapJsKey: KAKAO_MAP_JS_KEY || ''
  });
});

function toNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function toInteger(value) {
  const n = Number.parseInt(String(value ?? ''), 10);
  return Number.isFinite(n) ? n : null;
}

function pad4(value) {
  const n = Number.parseInt(String(value ?? '0'), 10);
  if (!Number.isFinite(n) || n < 0) return '0000';
  return String(n).padStart(4, '0');
}

function formatDateYYYYMMDD(value) {
  const raw = String(value || '').replace(/\D/g, '');
  if (raw.length !== 8) return value ? String(value) : '-';
  return `${raw.slice(0, 4)}-${raw.slice(4, 6)}-${raw.slice(6, 8)}`;
}

function pickFirst(item, keys, fallback = null) {
  for (const key of keys) {
    const value = item?.[key];
    if (value === undefined || value === null) continue;
    const text = String(value).trim();
    if (!text) continue;
    return value;
  }
  return fallback;
}

function normalizeItemsFromApi(rawResponse) {
  const body = rawResponse?.data?.response?.body || rawResponse?.response?.body || null;
  const raw = body?.items?.item;
  if (!raw) return [];
  return Array.isArray(raw) ? raw : [raw];
}

function safeLower(value) {
  return String(value || '').toLowerCase();
}

function normalizeNameToken(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/\s+/g, '')
    .replace(/[()\-_.]/g, '');
}

function toPyeongLabel(areaSquareMeter) {
  const area = Number(areaSquareMeter);
  if (!Number.isFinite(area) || area <= 0) return '-';
  const p = area / 3.305785;
  return `${p.toFixed(1)}평`;
}

function isValidResidentialArea(areaSquareMeter) {
  const area = Number(areaSquareMeter);
  if (!Number.isFinite(area)) return false;
  return area >= MIN_VALID_AREA_SQM && area <= MAX_VALID_AREA_SQM;
}

function recentDealMonths(count = 6) {
  const out = [];
  const now = new Date();
  let year = now.getFullYear();
  let month = now.getMonth() + 1;
  for (let i = 0; i < count; i += 1) {
    out.push(`${year}${String(month).padStart(2, '0')}`);
    month -= 1;
    if (month <= 0) {
      month = 12;
      year -= 1;
    }
  }
  return out;
}

function inferRegion(roadAddress, address) {
  const source = String(roadAddress || address || '').trim();
  if (!source) return '-';
  const parts = source.split(/\s+/).filter(Boolean);
  return parts.slice(0, 3).join(' ') || '-';
}

const EXCLUDED_PLACE_KEYWORDS = [
  '경비실',
  '관리사무소',
  '관리사무실',
  '수위실',
  '보안실',
  '경비초소'
];

function isExcludedPlaceDoc(doc) {
  const text = [
    String(doc?.place_name || ''),
    String(doc?.category_name || ''),
    String(doc?.road_address_name || ''),
    String(doc?.address_name || '')
  ].join(' ');
  return EXCLUDED_PLACE_KEYWORDS.some((keyword) => text.includes(keyword));
}

function pickPreferredKeywordDoc(docs = []) {
  if (!Array.isArray(docs) || !docs.length) return null;
  const filtered = docs.filter((doc) => !isExcludedPlaceDoc(doc));
  return filtered[0] || null;
}

function computeTravelMinutes(distance) {
  const d = Number(distance);
  if (!Number.isFinite(d)) return { walkMinutes: null, driveMinutes: null };
  return {
    walkMinutes: Math.max(1, Math.ceil(d / 67)),
    driveMinutes: Math.max(1, Math.ceil(d / 400))
  };
}

function haversineMeters(lat1, lng1, lat2, lng2) {
  const toRad = (v) => (v * Math.PI) / 180;
  const R = 6371000;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
    + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2))
    * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c);
}

function pointToSegmentDistanceMeters(point, a, b, latRef) {
  const meterPerLat = 111132;
  const meterPerLng = 111320 * Math.cos((latRef * Math.PI) / 180);

  const px = point.lng * meterPerLng;
  const py = point.lat * meterPerLat;
  const ax = a.lng * meterPerLng;
  const ay = a.lat * meterPerLat;
  const bx = b.lng * meterPerLng;
  const by = b.lat * meterPerLat;

  const abx = bx - ax;
  const aby = by - ay;
  const apx = px - ax;
  const apy = py - ay;
  const abLenSq = (abx * abx) + (aby * aby);
  if (abLenSq <= 0) {
    return Math.round(Math.sqrt((px - ax) ** 2 + (py - ay) ** 2));
  }
  const t = Math.max(0, Math.min(1, ((apx * abx) + (apy * aby)) / abLenSq));
  const cx = ax + (abx * t);
  const cy = ay + (aby * t);
  return Math.round(Math.sqrt((px - cx) ** 2 + (py - cy) ** 2));
}

function toBuildingParcelFromKakaoAddress(addressDoc) {
  const legalCode = String(addressDoc?.address?.b_code || '');
  if (legalCode.length < 10) return null;

  const mainAddressNo = pad4(addressDoc?.address?.main_address_no || '0');
  const subAddressNo = pad4(addressDoc?.address?.sub_address_no || '0');
  const mountainYn = String(addressDoc?.address?.mountain_yn || 'N').toUpperCase();
  return {
    sigunguCd: legalCode.slice(0, 5),
    bjdongCd: legalCode.slice(5, 10),
    platGbCd: mountainYn === 'Y' ? '1' : '0',
    bun: mainAddressNo,
    ji: subAddressNo
  };
}

async function callBuildingRegistryApi(operation, parcel, options = {}) {
  if (!BUILDING_REGISTRY_SERVICE_KEY || !parcel) return [];
  const {
    numOfRows = 300,
    timeoutMs = 25000,
    retries = 1
  } = options;

  let lastError = null;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    try {
      const response = await axios.get(`${BLD_REGISTRY_BASE_URL}/${operation}`, {
        params: {
          serviceKey: BUILDING_REGISTRY_SERVICE_KEY,
          sigunguCd: parcel.sigunguCd,
          bjdongCd: parcel.bjdongCd,
          platGbCd: parcel.platGbCd,
          bun: parcel.bun,
          ji: parcel.ji,
          numOfRows,
          pageNo: 1,
          _type: 'json'
        },
        timeout: timeoutMs
      });
      return normalizeItemsFromApi(response);
    } catch (error) {
      lastError = error;
      if (attempt < retries) {
        await new Promise((resolve) => setTimeout(resolve, 350 * (attempt + 1)));
      }
    }
  }
  throw lastError || new Error('건축물대장 API 호출 실패');
}

function mapBuildingRegistrySummary(titleItem, recapItem) {
  const merged = { ...(recapItem || {}), ...(titleItem || {}) };
  const groundFloors = toInteger(pickFirst(merged, ['grndFlrCnt']));
  const undergroundFloors = toInteger(pickFirst(merged, ['ugrndFlrCnt']));
  const heightNumber = toNumber(pickFirst(merged, ['heit']));
  const elevatorCount = toInteger(pickFirst(merged, ['rideUseElvtCnt']));
  const parkingCount = toInteger(pickFirst(merged, ['totPkngCnt', 'totParkngCnt']));
  const archArea = toNumber(pickFirst(merged, ['archArea']));
  const totalArea = toNumber(pickFirst(merged, ['totArea']));

  return {
    mainPurpose: String(pickFirst(merged, ['mainPurpsCdNm', 'mainPurpsNm'], '-')),
    structure: String(pickFirst(merged, ['strctCdNm', 'strctNm'], '-')),
    useApprovalDate: formatDateYYYYMMDD(pickFirst(merged, ['useAprDay', 'useAprDate'], '-')),
    groundFloors,
    undergroundFloors,
    heightMeters: heightNumber,
    passengerElevatorCount: elevatorCount,
    parkingCount,
    buildingArea: archArea,
    totalFloorArea: totalArea
  };
}

function mapDongInfo(floorItems, titleItems = []) {
  const grouped = new Map();
  floorItems.forEach((item) => {
    const dongName = String(pickFirst(item, ['dongNm', 'bldNm'], '동 미상'));
    if (!grouped.has(dongName)) {
      grouped.set(dongName, {
        dongName,
        floorCount: 0,
        maxFloor: null,
        minFloor: null
      });
    }
    const entry = grouped.get(dongName);
    entry.floorCount += 1;
    const floorNo = toInteger(pickFirst(item, ['flrNo']));
    if (Number.isFinite(floorNo)) {
      entry.maxFloor = entry.maxFloor === null ? floorNo : Math.max(entry.maxFloor, floorNo);
      entry.minFloor = entry.minFloor === null ? floorNo : Math.min(entry.minFloor, floorNo);
    }
  });
  if (grouped.size > 0) return [...grouped.values()];

  // Fallback: some parcels return no floor outline rows, but title rows still include dong names.
  titleItems.forEach((item) => {
    const dongName = String(pickFirst(item, ['dongNm', 'bldNm'], '')).trim();
    if (!dongName) return;
    if (!grouped.has(dongName)) {
      grouped.set(dongName, {
        dongName,
        floorCount: 0,
        maxFloor: null,
        minFloor: null
      });
    }
  });
  return [...grouped.values()];
}

function mapHoInfo(exclusiveItems) {
  return exclusiveItems
    .map((item) => {
      const area = toNumber(pickFirst(item, ['area']));
      return {
        dongName: String(pickFirst(item, ['dongNm'], '동 미상')),
        hoName: String(pickFirst(item, ['hoNm'], '-')),
        floorNumber: toInteger(pickFirst(item, ['flrNo'])),
        floorType: String(pickFirst(item, ['flrGbCdNm'], '-')),
        areaSquareMeter: area
      };
    })
    .filter((item) => item.hoName !== '-')
    .slice(0, 600);
}

async function fetchBuildingRegistryDetails(parcel) {
  if (!BUILDING_REGISTRY_SERVICE_KEY || !parcel) {
    return {
      available: false,
      reason: 'BUILDING_REGISTRY_SERVICE_KEY 누락 또는 지번 파라미터 부족',
      summary: null,
      dongInfo: [],
      hoInfo: []
    };
  }

  try {
    // Run sequentially so public API spikes/timeouts are less likely.
    const titleItems = await callBuildingRegistryApi('getBrTitleInfo', parcel, {
      numOfRows: 50,
      timeoutMs: 25000,
      retries: 1
    }).catch(() => []);
    const recapItems = await callBuildingRegistryApi('getBrRecapTitleInfo', parcel, {
      numOfRows: 50,
      timeoutMs: 25000,
      retries: 1
    }).catch(() => []);
    const floorItems = await callBuildingRegistryApi('getBrFlrOulnInfo', parcel, {
      numOfRows: 500,
      timeoutMs: 25000,
      retries: 1
    }).catch(() => []);
    const exclusiveItems = await callBuildingRegistryApi('getBrExposPubuseAreaInfo', parcel, {
      numOfRows: 500,
      timeoutMs: 25000,
      retries: 1
    }).catch(() => []);

    const summary = mapBuildingRegistrySummary(titleItems[0] || null, recapItems[0] || null);
    const dongInfo = mapDongInfo(floorItems, titleItems);
    const hoInfo = mapHoInfo(exclusiveItems);
    const noCoreData = !titleItems.length && !recapItems.length && !floorItems.length && !exclusiveItems.length;
    const reason = noCoreData
      ? '건축물대장 API 응답이 지연되거나 비어 있습니다. 잠시 후 다시 시도해 주세요.'
      : ((!dongInfo.length && !hoInfo.length)
          ? '해당 필지에서 동/호 공개 항목이 조회되지 않았습니다. (공공데이터 원본 미제공 또는 다른 대장 유형)'
          : '');

    return {
      available: !noCoreData,
      reason,
      summary,
      dongInfo,
      hoInfo,
      debug: {
        titleCount: titleItems.length,
        recapCount: recapItems.length,
        floorCount: floorItems.length,
        exclusiveCount: exclusiveItems.length
      }
    };
  } catch (error) {
    return {
      available: false,
      reason: `건축물대장 API 조회 실패: ${error.response?.data?.response?.header?.resultMsg || error.message}`,
      summary: null,
      dongInfo: [],
      hoInfo: [],
      debug: null
    };
  }
}

async function callRtmsApiByMonth(endpointUrl, lawdCd, dealYmd) {
  if (!MOLIT_RTMS_SERVICE_KEY) return [];
  const response = await axios.get(endpointUrl, {
    params: {
      serviceKey: MOLIT_RTMS_SERVICE_KEY,
      LAWD_CD: lawdCd,
      DEAL_YMD: dealYmd,
      numOfRows: 1000,
      pageNo: 1,
      _type: 'json'
    },
    timeout: 16000
  });
  return normalizeItemsFromApi(response);
}

async function fetchRtmsRecords(endpointUrl, lawdCd, months = []) {
  const rows = [];
  for (const month of months) {
    try {
      const items = await callRtmsApiByMonth(endpointUrl, lawdCd, month);
      rows.push(...items);
    } catch (_error) {
      // skip month-level failures and continue
    }
  }
  const seen = new Set();
  return rows.filter((row) => {
    const key = [
      String(pickFirst(row, ['aptNm', 'offiNm', 'sggCd'], '')),
      String(pickFirst(row, ['jibun', 'umdNm'], '')),
      String(pickFirst(row, ['excluUseAr', 'excluUseAr', 'buildingAr'], '')),
      String(pickFirst(row, ['floor'], '')),
      String(pickFirst(row, ['dealYear'], '')),
      String(pickFirst(row, ['dealMonth'], '')),
      String(pickFirst(row, ['dealDay'], '')),
      String(pickFirst(row, ['dealAmount'], ''))
    ].join('|');
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function buildHoCandidatesFromRtms(records, sourceType) {
  return records
    .map((row) => {
      const area = toNumber(pickFirst(row, ['excluUseAr', 'buildingAr', 'area']));
      const floor = toInteger(pickFirst(row, ['floor']));
      const dong = String(pickFirst(row, ['aptDong', 'dong', 'umdNm'], '-')).trim() || '-';
      const name = String(pickFirst(row, ['aptNm', 'offiNm'], '-')).trim() || '-';
      return {
        dongName: dong,
        hoName: floor ? `${floor}층` : '-',
        floorNumber: floor,
        floorType: sourceType === 'apt' ? '공동주택(실거래)' : '오피스텔(실거래)',
        areaSquareMeter: area,
        pyeongLabel: toPyeongLabel(area),
        name,
        source: sourceType
      };
    })
    .filter((item) => item.hoName !== '-' || Number.isFinite(item.areaSquareMeter))
    .slice(0, 300);
}

function groupDongCandidates(hoCandidates = []) {
  const map = new Map();
  hoCandidates.forEach((item) => {
    const key = item.dongName || '동 미상';
    if (!map.has(key)) {
      map.set(key, {
        dongName: key,
        floorCount: 0,
        maxFloor: null,
        minFloor: null
      });
    }
    const row = map.get(key);
    row.floorCount += 1;
    const f = Number(item.floorNumber);
    if (Number.isFinite(f)) {
      row.maxFloor = row.maxFloor === null ? f : Math.max(row.maxFloor, f);
      row.minFloor = row.minFloor === null ? f : Math.min(row.minFloor, f);
    }
  });
  return [...map.values()];
}

function toPnuFromParcel(parcel) {
  if (!parcel?.sigunguCd || !parcel?.bjdongCd || !parcel?.bun || !parcel?.ji) return null;
  const legal10 = `${parcel.sigunguCd}${parcel.bjdongCd}`;
  if (legal10.length !== 10) return null;
  const regstrSe = String(parcel.platGbCd) === '1' ? '2' : '1';
  return `${legal10}${regstrSe}${String(parcel.bun).padStart(4, '0')}${String(parcel.ji).padStart(4, '0')}`;
}

function normalizeVworldApartRows(raw) {
  const root = raw?.apartHousingPrices || raw || {};
  const row = root?.field;
  if (!row) return [];
  if (Array.isArray(row)) return row;
  return [row];
}

async function callVworldApartAttr(pnu, stdrYear, pageNo = 1, numOfRows = 300, filters = {}) {
  if (!VWORLD_APT_PRICE_KEY) {
    return { ok: false, reason: 'VWORLD_APT_PRICE_KEY 누락', rows: [] };
  }
  const response = await axios.get(VWORLD_APT_ATTR_URL, {
    params: {
      key: VWORLD_APT_PRICE_KEY,
      pnu,
      stdrYear,
      ...(filters?.dongNm ? { dongNm: filters.dongNm } : {}),
      ...(filters?.hoNm ? { hoNm: filters.hoNm } : {}),
      format: 'json',
      numOfRows,
      pageNo
    },
    timeout: 12000
  });
  const root = response.data?.apartHousingPrices || {};
  const resultCode = String(root?.resultCode || '');
  if (resultCode && resultCode !== 'SUCCESS') {
    return {
      ok: false,
      reason: `${resultCode}: ${String(root?.resultMsg || 'VWorld API 오류')}`,
      rows: []
    };
  }
  return {
    ok: true,
    reason: '',
    rows: normalizeVworldApartRows(response.data)
  };
}

async function fetchVworldApartAttrAllPages(pnu, stdrYear, filters = {}) {
  const pageSize = 100;
  const maxPages = 60;
  const merged = [];
  for (let pageNo = 1; pageNo <= maxPages; pageNo += 1) {
    const result = await callVworldApartAttr(pnu, stdrYear, pageNo, pageSize, filters);
    if (!result.ok) return result;
    const rows = Array.isArray(result.rows) ? result.rows : [];
    if (!rows.length) break;
    merged.push(...rows);
    if (rows.length < pageSize) break;
  }
  return { ok: true, reason: '', rows: merged };
}

function normalizeDongToken(value) {
  return String(value || '')
    .trim()
    .replace(/동$/u, '')
    .replace(/[^\dA-Za-z가-힣]/g, '');
}

function mapHoCandidatesFromVworld(rows = []) {
  return rows
    .map((item) => {
      const area = toNumber(pickFirst(item, ['prvuseAr']));
      const floorRaw = String(pickFirst(item, ['floorNm'], '')).trim();
      const floorNum = toInteger(floorRaw);
      return {
        dongName: String(pickFirst(item, ['dongNm'], '동 미상')).trim() || '동 미상',
        hoName: String(pickFirst(item, ['hoNm'], '-')).trim() || '-',
        floorNumber: floorNum,
        floorType: '공동주택가격',
        areaSquareMeter: area,
        pyeongLabel: toPyeongLabel(area),
        officialPrice: toNumber(pickFirst(item, ['pblntfPc'])),
        source: 'vworld'
      };
    })
    .filter((item) => item.hoName !== '-')
    .slice(0, 1000);
}

function pickRepresentativeUnits(hoCandidates = []) {
  const rows = Array.isArray(hoCandidates) ? hoCandidates : [];
  const map = new Map();
  rows.forEach((item) => {
    const dong = String(item?.dongName || '').trim();
    const ho = String(item?.hoName || '').trim();
    if (!dong || !ho) return;
    const key = `${dong}|${ho}`;
    const current = map.get(key);
    if (!current) {
      map.set(key, item);
      return;
    }
    const currentArea = Number(current?.areaSquareMeter);
    const nextArea = Number(item?.areaSquareMeter);
    const currentValid = Number.isFinite(currentArea) ? currentArea : -1;
    const nextValid = Number.isFinite(nextArea) ? nextArea : -1;
    if (nextValid > currentValid) {
      map.set(key, item);
    } else if (nextValid === currentValid) {
      const curPrice = Number(current?.officialPrice);
      const nextPrice = Number(item?.officialPrice);
      const curPriceValid = Number.isFinite(curPrice) ? curPrice : -1;
      const nextPriceValid = Number.isFinite(nextPrice) ? nextPrice : -1;
      if (nextPriceValid > curPriceValid) map.set(key, item);
    }
  });
  return [...map.values()];
}

function dedupeHoCandidates(hoCandidates = []) {
  const map = new Map();
  hoCandidates.forEach((item) => {
    const dong = String(item?.dongName || '').trim();
    const ho = String(item?.hoName || '').trim();
    if (!dong || !ho) return;
    const key = `${dong}|${ho}`;
    const prev = map.get(key);
    if (!prev) {
      map.set(key, item);
      return;
    }
    const prevScore = (Number.isFinite(Number(prev.officialPrice)) ? 2 : 0) + (isValidResidentialArea(prev.areaSquareMeter) ? 1 : 0);
    const nextScore = (Number.isFinite(Number(item.officialPrice)) ? 2 : 0) + (isValidResidentialArea(item.areaSquareMeter) ? 1 : 0);
    if (nextScore >= prevScore) map.set(key, item);
  });
  return [...map.values()];
}

function filterVerifiedVworldUnits(hoCandidates = []) {
  return dedupeHoCandidates(hoCandidates)
    .filter((item) => isValidResidentialArea(item.areaSquareMeter))
    .filter((item) => Number.isFinite(Number(item.officialPrice)) && Number(item.officialPrice) > 0);
}

function normalizeAreaBand(areaSquareMeter, step = 0.1) {
  const area = Number(areaSquareMeter);
  if (!Number.isFinite(area) || area <= 0) return null;
  const unit = Number(step);
  if (!Number.isFinite(unit) || unit <= 0) return area;
  return Math.round(area / unit) * unit;
}

function toPyeongNumber(areaSquareMeter) {
  const area = Number(areaSquareMeter);
  if (!Number.isFinite(area) || area <= 0) return null;
  return area / 3.3058;
}

function buildPyeongTypeList(hoCandidates = [], options = {}) {
  const source = Array.isArray(hoCandidates) ? hoCandidates : [];
  const {
    areaBandStep = 0.01,
    minUnits = 1,
    includePriceStats = true
  } = options;

  const grouped = new Map();
  source.forEach((item) => {
    const areaBand = normalizeAreaBand(item.areaSquareMeter, areaBandStep);
    if (!Number.isFinite(areaBand) || areaBand <= 0) return;
    const pyeongRaw = areaBand / 3.3058;
    const key = areaBand.toFixed(2);
    if (!grouped.has(key)) {
      grouped.set(key, {
        areaSqm: areaBand,
        pyeong: pyeongRaw,
        unitCount: 0,
        officialPriceMin: null,
        officialPriceMax: null
      });
    }
    const row = grouped.get(key);
    row.unitCount += 1;
    const price = Number(item.officialPrice);
    if (Number.isFinite(price) && price > 0) {
      row.officialPriceMin = row.officialPriceMin === null ? price : Math.min(row.officialPriceMin, price);
      row.officialPriceMax = row.officialPriceMax === null ? price : Math.max(row.officialPriceMax, price);
    }
  });

  return [...grouped.values()]
    .filter((row) => row.unitCount >= minUnits)
    .sort((a, b) => a.areaSqm - b.areaSqm)
    .map((row) => ({
      label: `${Number(row.pyeong.toFixed(1))}평형`,
      pyeong: Number(row.pyeong.toFixed(1)),
      areaSqm: Number(row.areaSqm.toFixed(2)),
      unitCount: row.unitCount,
      ...(includePriceStats
        ? {
            officialPriceMin: row.officialPriceMin,
            officialPriceMax: row.officialPriceMax
          }
        : {})
    }));
}

async function fetchVworldApartPriceUnits(parcel) {
  const pnu = toPnuFromParcel(parcel);
  if (!pnu) {
    return {
      available: false,
      reason: 'VWorld 조회용 PNU 생성 실패',
      year: null,
      pnu: null,
      hoCandidates: []
    };
  }
  if (!VWORLD_APT_PRICE_KEY) {
    return {
      available: false,
      reason: 'VWORLD_APT_PRICE_KEY 누락',
      year: null,
      pnu,
      hoCandidates: []
    };
  }

  const years = [new Date().getFullYear(), new Date().getFullYear() - 1, new Date().getFullYear() - 2];
  for (const y of years) {
    const result = await fetchVworldApartAttrAllPages(pnu, y).catch((error) => ({
      ok: false,
      reason: error.response?.data?.apartHousingPrices?.resultMsg || error.message || 'VWorld 조회 오류',
      rows: []
    }));
    if (!result.ok) {
      if (String(result.reason || '').includes('INCORRECT_KEY')) {
        return {
          available: false,
          reason: result.reason,
          year: y,
          pnu,
          hoCandidates: []
        };
      }
      continue;
    }
    const hoCandidates = mapHoCandidatesFromVworld(result.rows);
    if (hoCandidates.length) {
      return {
        available: true,
        reason: '',
        year: y,
        pnu,
        hoCandidates
      };
    }
  }

  return {
    available: false,
    reason: 'VWorld 공동주택가격에서 동/호 데이터를 찾지 못했습니다.',
    year: null,
    pnu,
    hoCandidates: []
  };
}

function filterRtmsByBuildingName(records, buildingName) {
  if (!buildingName) return records;
  const target = normalizeNameToken(buildingName);
  if (!target) return records;
  const filtered = records.filter((row) => {
    const aptNm = normalizeNameToken(pickFirst(row, ['aptNm', 'offiNm'], ''));
    return aptNm && (aptNm.includes(target) || target.includes(aptNm));
  });
  return filtered.length ? filtered : records;
}

function mergeDongCandidates(primary = [], supplement = []) {
  const map = new Map();
  [...primary, ...supplement].forEach((item) => {
    const key = String(item?.dongName || '').trim();
    if (!key) return;
    if (!map.has(key)) {
      map.set(key, { ...item });
      return;
    }
    const current = map.get(key);
    const merged = {
      ...item,
      ...current,
      dongName: key,
      floorCount: Number.isFinite(Number(current.floorCount)) ? current.floorCount : item.floorCount,
      maxFloor: Number.isFinite(Number(current.maxFloor)) ? current.maxFloor : item.maxFloor,
      minFloor: Number.isFinite(Number(current.minFloor)) ? current.minFloor : item.minFloor,
      source: current.source || item.source || 'reb'
    };
    map.set(key, merged);
  });
  return [...map.values()];
}

function toRebDongCandidates(dongItems = []) {
  return dongItems
    .map((item) => {
      const dongName = String(pickFirst(item, ['DONG_NM2', 'DONG_NM1', 'DONG_NM3'], '')).trim() || '동 미상';
      const groundFloor = toInteger(pickFirst(item, ['GRND_FLR_CNT']));
      return {
        dongName,
        floorCount: Number.isFinite(groundFloor) && groundFloor > 0 ? groundFloor : 0,
        maxFloor: Number.isFinite(groundFloor) && groundFloor > 0 ? groundFloor : null,
        minFloor: Number.isFinite(groundFloor) && groundFloor > 0 ? 1 : null,
        source: 'reb'
      };
    })
    .slice(0, 400);
}

function compactAddressLikeTerm(value) {
  return String(value || '')
    .replace(/[()]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function expandSidoName(term) {
  const t = compactAddressLikeTerm(term);
  if (!t) return t;
  const pairs = [
    ['서울 ', '서울특별시 '],
    ['부산 ', '부산광역시 '],
    ['대구 ', '대구광역시 '],
    ['인천 ', '인천광역시 '],
    ['광주 ', '광주광역시 '],
    ['대전 ', '대전광역시 '],
    ['울산 ', '울산광역시 '],
    ['세종 ', '세종특별자치시 '],
    ['경기 ', '경기도 '],
    ['강원 ', '강원특별자치도 '],
    ['충북 ', '충청북도 '],
    ['충남 ', '충청남도 '],
    ['전북 ', '전북특별자치도 '],
    ['전남 ', '전라남도 '],
    ['경북 ', '경상북도 '],
    ['경남 ', '경상남도 '],
    ['제주 ', '제주특별자치도 ']
  ];
  for (const [shortForm, fullForm] of pairs) {
    if (t.startsWith(shortForm)) {
      return `${fullForm}${t.slice(shortForm.length)}`.trim();
    }
  }
  return t;
}

function buildRebAddressSearchTerms(building = {}) {
  const source = [
    building.roadAddress,
    building.address,
    building.fullAddress
  ]
    .map((v) => compactAddressLikeTerm(v))
    .filter(Boolean);

  const terms = new Set();
  source.forEach((text) => {
    const parts = text.split(' ').filter(Boolean);
    terms.add(text);
    terms.add(expandSidoName(text));
    if (parts.length >= 4) terms.add(parts.slice(0, 4).join(' '));
    if (parts.length >= 3) terms.add(parts.slice(0, 3).join(' '));
    if (parts.length >= 2) terms.add(parts.slice(0, 2).join(' '));
    if (parts.length >= 4) terms.add(expandSidoName(parts.slice(0, 4).join(' ')));
    if (parts.length >= 3) terms.add(expandSidoName(parts.slice(0, 3).join(' ')));
    if (parts.length >= 2) terms.add(expandSidoName(parts.slice(0, 2).join(' ')));
  });
  return [...terms].filter((v) => v.length >= 4).slice(0, 6);
}

async function callRebAptIdInfoByAddress(addressLike) {
  const response = await axios.get(`${REB_APTID_BASE_URL}/getAptInfo`, {
    params: {
      serviceKey: REB_APTID_SERVICE_KEY,
      page: 1,
      perPage: 100,
      returnType: 'JSON',
      'cond[ADRES::LIKE]': addressLike
    },
    timeout: 12000
  });
  return Array.isArray(response.data?.data) ? response.data.data : [];
}

function scoreRebComplex(row, normalized) {
  const rowAddrRaw = String(pickFirst(row, ['ADRES'], ''));
  const targetAddrRaw = String(
    normalized?.building?.address || normalized?.building?.roadAddress || normalized?.building?.fullAddress || ''
  );
  const rowAddr = normalizeNameToken(rowAddrRaw);
  const targetAddr = normalizeNameToken(targetAddrRaw);
  const rowName = normalizeNameToken(
    pickFirst(row, ['COMPLEX_NM2', 'COMPLEX_NM1', 'COMPLEX_NM3'], '')
  );
  const targetName = normalizeNameToken(normalized?.building?.name || '');
  const rowAddrKey = compactAddressLikeTerm(rowAddrRaw).split(' ').slice(0, 3).join(' ');
  const targetAddrKey = compactAddressLikeTerm(targetAddrRaw).split(' ').slice(0, 3).join(' ');

  let score = 0;
  if (rowAddrKey && targetAddrKey) {
    if (rowAddrKey === targetAddrKey) score += 6;
    else score -= 6;
  }
  if (targetAddr && rowAddr) {
    if (targetAddr.includes(rowAddr)) score += 5;
    else if (rowAddr.includes(targetAddr)) score += 4;
  }
  if (targetName && rowName) {
    if (targetName.includes(rowName) || rowName.includes(targetName)) score += 4;
  }
  if (String(pickFirst(row, ['COMPLEX_GB_CD'], '')) === '1') score += 1;
  const unitCnt = Math.max(0, toInteger(pickFirst(row, ['UNIT_CNT'])) || 0);
  score += Math.min(0.5, unitCnt / 10000);
  return score;
}

async function callRebDongInfoByComplexPk(complexPk) {
  const response = await axios.get(`${REB_APTID_BASE_URL}/getDongInfo`, {
    params: {
      serviceKey: REB_APTID_SERVICE_KEY,
      page: 1,
      perPage: 500,
      returnType: 'JSON',
      'cond[COMPLEX_PK::EQ]': String(complexPk || '')
    },
    timeout: 12000
  });
  return Array.isArray(response.data?.data) ? response.data.data : [];
}

async function fetchRebAptIdDetails(normalized) {
  if (!REB_APTID_SERVICE_KEY) {
    return {
      available: false,
      reason: 'REB_APTID_SERVICE_KEY 누락',
      complex: null,
      dongInfo: []
    };
  }

  const terms = buildRebAddressSearchTerms(normalized?.building || {});
  if (!terms.length) {
    return {
      available: false,
      reason: 'REB 단지 검색용 주소 텍스트 부족',
      complex: null,
      dongInfo: []
    };
  }

  let rows = [];
  for (const term of terms) {
    try {
      const items = await callRebAptIdInfoByAddress(term);
      if (items.length) {
        rows = items;
        break;
      }
    } catch (_error) {
      // continue next address term
    }
  }

  if (!rows.length) {
    return {
      available: false,
      reason: 'REB 단지 식별정보 매칭 결과 없음',
      complex: null,
      dongInfo: []
    };
  }

  const sorted = rows
    .map((row) => ({
      row,
      score: scoreRebComplex(row, normalized)
    }))
    .sort((a, b) => b.score - a.score);
  if (!sorted.length || sorted[0].score <= 0) {
    return {
      available: false,
      reason: 'REB 단지식별 매칭 신뢰도가 낮아 보강 정보를 제외했습니다.',
      complex: null,
      dongInfo: []
    };
  }
  const best = sorted[0]?.row || null;
  const complexPk = pickFirst(best || {}, ['COMPLEX_PK'], '');
  if (!complexPk) {
    return {
      available: false,
      reason: 'REB 단지 식별정보에서 단지고유번호를 찾지 못했습니다.',
      complex: null,
      dongInfo: []
    };
  }

  const dongRaw = await callRebDongInfoByComplexPk(complexPk).catch(() => []);
  const dongInfo = toRebDongCandidates(dongRaw);

  return {
    available: true,
    reason: dongInfo.length ? '' : 'REB 동정보가 비어 있습니다.',
    complex: {
      complexPk: String(pickFirst(best, ['COMPLEX_PK'], '')),
      pnu: String(pickFirst(best, ['PNU'], '')),
      address: String(pickFirst(best, ['ADRES'], '')),
      complexName: String(pickFirst(best, ['COMPLEX_NM2', 'COMPLEX_NM1', 'COMPLEX_NM3'], '-')),
      dongCount: toInteger(pickFirst(best, ['DONG_CNT'])),
      unitCount: toInteger(pickFirst(best, ['UNIT_CNT'])),
      useApprovalDate: formatDateYYYYMMDD(pickFirst(best, ['USEAPR_DT'], ''))
    },
    dongInfo
  };
}

async function fetchHousingUnitPipeline(normalized, registry, rebAptId, vworldAptPrice) {
  const fromRegistry = Array.isArray(registry?.hoInfo) ? registry.hoInfo : [];
  const fromRegistryDong = Array.isArray(registry?.dongInfo) ? registry.dongInfo : [];
  const fromRebDong = Array.isArray(rebAptId?.dongInfo) ? rebAptId.dongInfo : [];
  const fromVworld = Array.isArray(vworldAptPrice?.hoCandidates) ? vworldAptPrice.hoCandidates : [];
  const fromVworldUnits = pickRepresentativeUnits(fromVworld);

  if (fromVworldUnits.length) {
    return {
      source: 'vworld-apt-price',
      hoCandidates: fromVworldUnits,
      dongCandidates: mergeDongCandidates(groupDongCandidates(fromVworldUnits), fromRebDong),
      note: ''
    };
  }

  if (fromRegistry.length || fromRegistryDong.length) {
    const fromRegistryUnits = pickRepresentativeUnits(fromRegistry.map((item) => ({
      ...item,
      pyeongLabel: toPyeongLabel(item.areaSquareMeter),
      source: 'registry'
    })));
    return {
      source: 'building-registry',
      hoCandidates: fromRegistryUnits,
      dongCandidates: mergeDongCandidates(
        fromRegistryDong.map((item) => ({ ...item, source: item.source || 'registry' })),
        fromRebDong
      ),
      note: ''
    };
  }

  const lawdCd = String(normalized?.parcel?.sigunguCd || '');
  if (!MOLIT_RTMS_SERVICE_KEY || lawdCd.length !== 5) {
    return {
      source: 'none',
      hoCandidates: [],
      dongCandidates: [],
      note: '실거래 API 키 미설정 또는 법정동 코드 부족'
    };
  }

  const months = recentDealMonths(6);
  const [aptRowsRaw, offiRowsRaw] = await Promise.all([
    fetchRtmsRecords(RTMS_APT_URL, lawdCd, months),
    fetchRtmsRecords(RTMS_OFFI_URL, lawdCd, months)
  ]);

  const aptRows = filterRtmsByBuildingName(aptRowsRaw, normalized?.building?.name || '');
  const offiRows = filterRtmsByBuildingName(offiRowsRaw, normalized?.building?.name || '');

  const hoCandidates = [
    ...buildHoCandidatesFromRtms(aptRows, 'apt'),
    ...buildHoCandidatesFromRtms(offiRows, 'officetel')
  ].slice(0, 300);
  const dongCandidates = mergeDongCandidates(groupDongCandidates(hoCandidates), fromRebDong);

  return {
    source: 'rtms-fallback',
    hoCandidates: [],
    dongCandidates,
    note: dongCandidates.length
      ? '실거래 기반 동/층 후보만 확인되었습니다. 실제 평수/호수 검증(VWorld) 데이터가 없어 호수를 미표시합니다.'
      : '실거래 데이터에서도 동/층 후보를 찾지 못했습니다.'
  };
}

function buildRegistryLinkageInfo(normalized, registry, housingPipeline) {
  const hasParcelKey = Boolean(
    normalized?.parcel?.sigunguCd
    && normalized?.parcel?.bjdongCd
    && normalized?.parcel?.platGbCd
    && normalized?.parcel?.bun
    && normalized?.parcel?.ji
  );
  const fromRegistry = Boolean(Array.isArray(registry?.hoInfo) && registry.hoInfo.length > 0);
  const fromFallback = Boolean(housingPipeline?.source === 'rtms-fallback');

  const sourceType = fromRegistry
    ? 'building-registry'
    : (fromFallback ? 'rtms-fallback' : 'none');

  return {
    usableForRegistryWorkflow: hasParcelKey,
    sourceType,
    confidence: fromRegistry ? 'high' : (fromFallback ? 'low' : 'none'),
    note: fromRegistry
      ? '동/호가 건축물대장 전유부/층별 개요 원본입니다. 등기 열람 결과와 대조용으로 사용 가능합니다.'
      : (fromFallback
        ? '동/호가 실거래 기반 후보 데이터입니다. 등기/건축물대장 원본과 불일치할 수 있습니다.'
        : (registry?.reason || '동/호 데이터 원본을 확인하지 못했습니다.')),
    parcelKey: hasParcelKey
      ? {
          sigunguCd: String(normalized.parcel.sigunguCd),
          bjdongCd: String(normalized.parcel.bjdongCd),
          platGbCd: String(normalized.parcel.platGbCd),
          bun: String(normalized.parcel.bun),
          ji: String(normalized.parcel.ji)
        }
      : null
  };
}

function normalizeOverpassPoint(item) {
  const lat = toNumber(item.lat) || toNumber(item.center?.lat);
  const lng = toNumber(item.lon) || toNumber(item.center?.lon);
  if (!lat || !lng) return null;
  return { lat, lng };
}

function nearestFromPoints(center, items, predicate) {
  const candidates = items
    .filter((item) => predicate(item))
    .map((item) => {
      const point = normalizeOverpassPoint(item);
      if (!point) return null;
      const distance = haversineMeters(center.lat, center.lng, point.lat, point.lng);
      return { item, point, distance };
    })
    .filter(Boolean)
    .sort((a, b) => a.distance - b.distance);
  return candidates[0] || null;
}

function mapNearestResult(nearest, fallbackName = '-') {
  if (!nearest) {
    return {
      name: '-',
      distanceMeters: null,
      walkMinutes: null,
      driveMinutes: null,
      lat: null,
      lng: null
    };
  }
  const tags = nearest.item.tags || {};
  const travel = computeTravelMinutes(nearest.distance);
  return {
    name: String(tags.name || tags.brand || fallbackName),
    distanceMeters: nearest.distance,
    walkMinutes: travel.walkMinutes,
    driveMinutes: travel.driveMinutes,
    lat: nearest.point.lat,
    lng: nearest.point.lng
  };
}

function classifySchoolLevel(name) {
  const n = String(name || '');
  if (/초등|elementary/i.test(n)) return 'elementary';
  if (/중학|middle/i.test(n)) return 'middle';
  if (/고등|high/i.test(n)) return 'high';
  return 'unknown';
}

function chooseCloserItem(a, b) {
  const da = Number(a?.distanceMeters);
  const db = Number(b?.distanceMeters);
  const aValid = Number.isFinite(da);
  const bValid = Number.isFinite(db);
  if (aValid && bValid) return da <= db ? a : b;
  if (aValid) return a;
  if (bValid) return b;
  return null;
}

function limitByDistance(item, maxMeters = 1000) {
  const d = Number(item?.distanceMeters);
  if (!Number.isFinite(d) || d < 0) return null;
  if (d >= maxMeters) return null;
  return item;
}

async function searchNearestKakaoKeyword(center, options) {
  const {
    query,
    radius = 2500,
    size = 15,
    filterFn = null,
    fallbackName = '-'
  } = options || {};
  if (!KAKAO_REST_API_KEY) return null;
  const headers = { Authorization: `KakaoAK ${KAKAO_REST_API_KEY}` };
  const response = await axios.get(`${KAKAO_BASE_URL}/search/keyword.json`, {
    params: {
      query,
      x: center.lng,
      y: center.lat,
      radius,
      sort: 'distance',
      size
    },
    headers,
    timeout: 9000
  });
  const docs = (response.data?.documents || [])
    .filter((doc) => !isExcludedPlaceDoc(doc))
    .filter((doc) => {
      const distance = Number.parseInt(String(doc.distance || '0'), 10);
      return Number.isFinite(distance) && distance >= 0;
    })
    .filter((doc) => (typeof filterFn === 'function' ? filterFn(doc) : true))
    .sort((a, b) => Number(a.distance) - Number(b.distance));
  const doc = docs[0];
  if (!doc) return null;
  const distanceMeters = Number.parseInt(String(doc.distance || '0'), 10);
  const travel = computeTravelMinutes(distanceMeters);
  return {
    name: String(doc.place_name || fallbackName || query),
    distanceMeters: Number.isFinite(distanceMeters) ? distanceMeters : null,
    walkMinutes: travel.walkMinutes,
    driveMinutes: travel.driveMinutes,
    lat: toNumber(doc.y),
    lng: toNumber(doc.x)
  };
}

async function fetchTransitWithKakao(center) {
  if (!KAKAO_REST_API_KEY) return null;
  const [bus, subway, parking, elementary, middle, high] = await Promise.all([
    searchNearestKakaoKeyword(center, {
      query: '버스정류장',
      radius: 2500,
      filterFn: (doc) => {
        const text = `${doc.place_name || ''} ${doc.category_name || ''} ${doc.category_group_name || ''}`;
        return /버스정류장|정류소|버스스탑|버스정류/.test(text);
      },
      fallbackName: '가까운 버스정류장'
    }),
    searchNearestKakaoKeyword(center, {
      query: '지하철역',
      radius: 4000,
      filterFn: (doc) => String(doc.category_group_code || '') === 'SW8'
        || /지하철역|전철역/.test(`${doc.place_name || ''} ${doc.category_name || ''}`),
      fallbackName: '가까운 지하철역'
    }),
    searchNearestKakaoKeyword(center, {
      query: '주차장',
      radius: 2500,
      filterFn: (doc) => String(doc.category_group_code || '') === 'PK6'
        || /주차장/.test(`${doc.place_name || ''} ${doc.category_name || ''}`),
      fallbackName: '인근 주차장'
    }),
    searchNearestKakaoKeyword(center, {
      query: '초등학교',
      radius: 4000,
      filterFn: (doc) => /초등/.test(`${doc.place_name || ''} ${doc.category_name || ''}`),
      fallbackName: '가까운 초등학교'
    }),
    searchNearestKakaoKeyword(center, {
      query: '중학교',
      radius: 4000,
      filterFn: (doc) => /중학교|중학/.test(`${doc.place_name || ''} ${doc.category_name || ''}`),
      fallbackName: '가까운 중학교'
    }),
    searchNearestKakaoKeyword(center, {
      query: '고등학교',
      radius: 5000,
      filterFn: (doc) => /고등/.test(`${doc.place_name || ''} ${doc.category_name || ''}`),
      fallbackName: '가까운 고등학교'
    })
  ]);
  return {
    bus: bus || mapNearestResult(null, '가까운 버스정류장'),
    subway: subway || mapNearestResult(null, '가까운 지하철역'),
    parking: parking || mapNearestResult(null, '인근 주차장'),
    schools: {
      elementary: elementary || mapNearestResult(null, '가까운 초등학교'),
      middle: middle || mapNearestResult(null, '가까운 중학교'),
      high: high || mapNearestResult(null, '가까운 고등학교')
    }
  };
}

function inferRoadSurface(surfaceText) {
  const t = String(surfaceText || '').toLowerCase();
  if (!t) return '정보없음';
  if (/(asphalt|paved|concrete|paving_stones|sett)/.test(t)) return '포장';
  if (/(gravel|ground|dirt|earth|unpaved|mud|sand)/.test(t)) return '비포장';
  return '혼합/기타';
}

function inferRoadEase(surface, sidewalkTag) {
  const paved = surface === '포장';
  const sidewalk = String(sidewalkTag || '').toLowerCase();
  const hasSidewalk = ['yes', 'both', 'left', 'right', 'separate'].includes(sidewalk);
  if (paved && hasSidewalk) return '용이함';
  if (!paved) return '불편함';
  return '보통';
}

function computeRoadAccess(center, wayElements) {
  let nearest = null;
  wayElements.forEach((way) => {
    if (!Array.isArray(way.geometry) || way.geometry.length < 2) return;
    for (let i = 1; i < way.geometry.length; i += 1) {
      const prev = way.geometry[i - 1];
      const curr = way.geometry[i];
      const prevPoint = { lat: Number(prev.lat), lng: Number(prev.lon) };
      const currPoint = { lat: Number(curr.lat), lng: Number(curr.lon) };
      if (!Number.isFinite(prevPoint.lat) || !Number.isFinite(prevPoint.lng)) continue;
      if (!Number.isFinite(currPoint.lat) || !Number.isFinite(currPoint.lng)) continue;
      const segmentDistance = pointToSegmentDistanceMeters(center, prevPoint, currPoint, center.lat);
      if (!nearest || segmentDistance < nearest.distanceMeters) {
        nearest = { way, distanceMeters: segmentDistance };
      }
    }
  });

  if (!nearest) {
    return {
      surfaceType: '정보없음',
      ease: '정보없음',
      contactDistanceMeters: null
    };
  }

  const tags = nearest.way.tags || {};
  const surface = inferRoadSurface(tags.surface);
  return {
    surfaceType: surface,
    ease: inferRoadEase(surface, tags.sidewalk),
    contactDistanceMeters: nearest.distanceMeters
  };
}

function mapNearbyFromOverpass(center, elements) {
  const items = elements
    .map((item) => {
      const point = normalizeOverpassPoint(item);
      if (!point) return null;
      const tags = item.tags || {};
      const category = tags.amenity || tags.shop || tags.public_transport || tags.railway || '시설';
      const distance = haversineMeters(center.lat, center.lng, point.lat, point.lng);
      const travel = computeTravelMinutes(distance);
      return {
        id: String(item.id || `${tags.name || category}-${point.lat}-${point.lng}`),
        name: String(tags.name || tags.brand || category),
        category,
        distance,
        address: String(tags['addr:full'] || ''),
        roadAddress: '',
        phone: String(tags.phone || ''),
        placeUrl: '',
        lat: point.lat,
        lng: point.lng,
        walkMinutes: travel.walkMinutes,
        driveMinutes: travel.driveMinutes
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.distance - b.distance);

  const seen = new Set();
  return items.filter((item) => {
    const key = `${item.name}-${item.lat}-${item.lng}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 60);
}

async function fetchMobilityAndRoad(center) {
  const query = `
[out:json][timeout:20];
(
  node(around:1800,${center.lat},${center.lng})["highway"="bus_stop"];
  node(around:1800,${center.lat},${center.lng})["public_transport"="platform"]["bus"="yes"];
  node(around:2500,${center.lat},${center.lng})["railway"="station"]["station"="subway"];
  node(around:1200,${center.lat},${center.lng})["amenity"="parking"];
  way(around:1200,${center.lat},${center.lng})["amenity"="parking"];
  node(around:2000,${center.lat},${center.lng})["amenity"="school"];
  way(around:2000,${center.lat},${center.lng})["amenity"="school"];
  node(around:1200,${center.lat},${center.lng})["amenity"~"hospital|pharmacy|cafe|restaurant"];
  node(around:1200,${center.lat},${center.lng})["shop"="convenience"];
  way(around:1200,${center.lat},${center.lng})["amenity"~"hospital|pharmacy|cafe|restaurant"];
  way(around:1200,${center.lat},${center.lng})["shop"="convenience"];
  way(around:350,${center.lat},${center.lng})["highway"]["highway"~"motorway|trunk|primary|secondary|tertiary|residential|service|unclassified|living_street"];
);
out center geom 200;`;

  const response = await axios.post('https://overpass-api.de/api/interpreter', query, {
    headers: { 'Content-Type': 'text/plain' },
    timeout: 15000
  });
  const elements = response.data?.elements || [];

  const roadWays = elements.filter((item) => item.type === 'way' && item.tags?.highway);
  const roadAccess = computeRoadAccess(center, roadWays);

  const busNearest = nearestFromPoints(
    center,
    elements,
    (item) => item.tags?.highway === 'bus_stop'
      || item.tags?.public_transport === 'stop_position'
      || (item.tags?.public_transport === 'platform' && item.tags?.bus === 'yes')
  );
  const subwayNearest = nearestFromPoints(
    center,
    elements,
    (item) => item.tags?.railway === 'station'
      && (item.tags?.station === 'subway' || item.tags?.subway === 'yes')
  );
  const parkingNearest = nearestFromPoints(
    center,
    elements,
    (item) => item.tags?.amenity === 'parking'
  );

  const schoolNearestByLevel = { elementary: null, middle: null, high: null };
  elements.forEach((item) => {
    if (item.tags?.amenity !== 'school') return;
    const point = normalizeOverpassPoint(item);
    if (!point) return;
    const distance = haversineMeters(center.lat, center.lng, point.lat, point.lng);
    const level = classifySchoolLevel(item.tags?.name);
    if (level === 'unknown') return;
    if (!schoolNearestByLevel[level] || distance < schoolNearestByLevel[level].distance) {
      schoolNearestByLevel[level] = { item, point, distance };
    }
  });

  const osmTransit = {
    bus: mapNearestResult(busNearest, '가까운 버스정류장'),
    subway: mapNearestResult(subwayNearest, '가까운 지하철역'),
    parking: mapNearestResult(parkingNearest, '인근 주차장'),
    schools: {
      elementary: mapNearestResult(schoolNearestByLevel.elementary, '가까운 초등학교'),
      middle: mapNearestResult(schoolNearestByLevel.middle, '가까운 중학교'),
      high: mapNearestResult(schoolNearestByLevel.high, '가까운 고등학교')
    }
  };

  const kakaoTransit = await fetchTransitWithKakao(center).catch(() => null);
  const mergedTransit = {
    bus: limitByDistance(chooseCloserItem(kakaoTransit?.bus, osmTransit.bus), 1000) || mapNearestResult(null, '가까운 버스정류장'),
    subway: limitByDistance(chooseCloserItem(kakaoTransit?.subway, osmTransit.subway), 1000) || mapNearestResult(null, '가까운 지하철역'),
    parking: limitByDistance(chooseCloserItem(kakaoTransit?.parking, osmTransit.parking), 1000) || mapNearestResult(null, '인근 주차장'),
    schools: {
      elementary: limitByDistance(chooseCloserItem(kakaoTransit?.schools?.elementary, osmTransit.schools.elementary), 1000) || mapNearestResult(null, '가까운 초등학교'),
      middle: limitByDistance(chooseCloserItem(kakaoTransit?.schools?.middle, osmTransit.schools.middle), 1000) || mapNearestResult(null, '가까운 중학교'),
      high: limitByDistance(chooseCloserItem(kakaoTransit?.schools?.high, osmTransit.schools.high), 1000) || mapNearestResult(null, '가까운 고등학교')
    }
  };

  return {
    roadAccess,
    transit: mergedTransit,
    nearbyItems: mapNearbyFromOverpass(center, elements)
      .filter((item) => Number.isFinite(Number(item.distance)) && Number(item.distance) < 1000)
  };
}

function mapOsmNearbyItem(item, centerLat, centerLng) {
  const lat = toNumber(item.lat) || toNumber(item.center?.lat);
  const lng = toNumber(item.lon) || toNumber(item.center?.lon);
  if (!lat || !lng) return null;
  const tag = item.tags || {};
  const name = tag.name || tag.brand || '주변 시설';
  const amenity = tag.amenity || tag.shop || tag.public_transport || '시설';
  const roughMeters = Math.round(
    Math.sqrt(((lat - centerLat) * 111000) ** 2 + ((lng - centerLng) * 88000) ** 2)
  );
  const travel = computeTravelMinutes(roughMeters);
  return {
    id: String(item.id || `${name}-${lat}-${lng}`),
    name: String(name),
    category: String(amenity),
    distance: roughMeters,
    address: String(tag['addr:full'] || ''),
    roadAddress: '',
    phone: String(tag.phone || ''),
    placeUrl: '',
    lat,
    lng,
    walkMinutes: travel.walkMinutes,
    driveMinutes: travel.driveMinutes
  };
}

async function searchWithOsm(query) {
  const nominatim = await axios.get('https://nominatim.openstreetmap.org/search', {
    params: {
      q: query,
      format: 'jsonv2',
      addressdetails: 1,
      limit: 1
    },
    headers: { 'User-Agent': 'building-info-app/1.0' },
    timeout: 9000
  });

  const first = nominatim.data?.[0];
  if (!first) throw new Error('주소 검색 결과가 없습니다.');

  const lat = toNumber(first.lat);
  const lng = toNumber(first.lon);
  if (!lat || !lng) throw new Error('좌표를 찾을 수 없습니다.');

  const overpassQuery = `
[out:json][timeout:12];
(
  node(around:1200,${lat},${lng})["amenity"~"school|hospital|pharmacy|cafe|restaurant|bank|police|post_office|bus_station"];
  way(around:1200,${lat},${lng})["amenity"~"school|hospital|pharmacy|cafe|restaurant|bank|police|post_office|bus_station"];
  node(around:1200,${lat},${lng})["shop"="convenience"];
  way(around:1200,${lat},${lng})["shop"="convenience"];
);
out center 40;`;

  const overpass = await axios.post('https://overpass-api.de/api/interpreter', overpassQuery, {
    headers: { 'Content-Type': 'text/plain' },
    timeout: 12000
  });

  const nearbyItems = (overpass.data?.elements || [])
    .map((item) => mapOsmNearbyItem(item, lat, lng))
    .filter(Boolean)
    .sort((a, b) => (a.distance || 999999) - (b.distance || 999999))
    .slice(0, 40);

  const displayName = String(first.display_name || '');
  const region = displayName.split(',').slice(-3).reverse().join(' ').trim() || '-';

  return {
    provider: 'OpenStreetMap',
    building: {
      name: first.name || '검색 건물',
      fullAddress: displayName,
      roadAddress: displayName,
      address: displayName,
      category: String(first.type || '건물'),
      use: String(first.class || '미지정'),
      region,
      lat,
      lng,
      placeUrl: first.osm_id
        ? `https://www.openstreetmap.org/${first.osm_type}/${first.osm_id}`
        : '',
      phone: ''
    },
    nearbyItems
  };
}

async function resolveAddressWithKakao(query) {
  const headers = { Authorization: `KakaoAK ${KAKAO_REST_API_KEY}` };
  const addrRes = await axios.get(`${KAKAO_BASE_URL}/search/address.json`, {
    params: { query, size: 1 },
    headers,
    timeout: 9000
  });
  let addressDoc = addrRes.data?.documents?.[0] || null;
  let keywordDoc = null;

  if (!addressDoc) {
    const kwRes = await axios.get(`${KAKAO_BASE_URL}/search/keyword.json`, {
      params: { query, size: 7, sort: 'accuracy' },
      headers,
      timeout: 9000
    });
    keywordDoc = pickPreferredKeywordDoc(kwRes.data?.documents || []);
    if (!keywordDoc) {
      throw new Error('주소 또는 건물명 검색 결과가 없습니다.');
    }
    const addressLike = keywordDoc.road_address_name || keywordDoc.address_name;
    if (addressLike) {
      const normalized = await axios.get(`${KAKAO_BASE_URL}/search/address.json`, {
        params: { query: addressLike, size: 1 },
        headers,
        timeout: 9000
      });
      addressDoc = normalized.data?.documents?.[0] || null;
    }
  } else {
    const lat = toNumber(addressDoc.y);
    const lng = toNumber(addressDoc.x);
    if (lat && lng) {
      const kwRes = await axios.get(`${KAKAO_BASE_URL}/search/keyword.json`, {
        params: {
          query,
          x: lng,
          y: lat,
          radius: 600,
          sort: 'distance',
          size: 7
        },
        headers,
        timeout: 9000
      });
      keywordDoc = pickPreferredKeywordDoc(kwRes.data?.documents || []);
    }
  }

  if (!addressDoc) throw new Error('주소 정규화에 실패했습니다.');

  const lat = toNumber(addressDoc.y) || toNumber(keywordDoc?.y);
  const lng = toNumber(addressDoc.x) || toNumber(keywordDoc?.x);
  if (!lat || !lng) throw new Error('좌표를 찾을 수 없습니다.');

  const parcel = toBuildingParcelFromKakaoAddress(addressDoc);
  return {
    provider: 'Kakao Local API',
    building: {
      name: keywordDoc?.place_name || addressDoc.address?.building_name || '검색 건물',
      fullAddress: String(addressDoc.address_name || ''),
      roadAddress: String(addressDoc.road_address?.address_name || keywordDoc?.road_address_name || ''),
      address: String(addressDoc.address?.address_name || keywordDoc?.address_name || addressDoc.address_name || ''),
      category: String(keywordDoc?.category_group_name || keywordDoc?.category_name || '건물'),
      use: String(keywordDoc?.category_name || '미지정'),
      region: inferRegion(addressDoc.road_address?.address_name, addressDoc.address_name),
      lat,
      lng,
      placeUrl: String(keywordDoc?.place_url || ''),
      phone: String(keywordDoc?.phone || '')
    },
    parcel
  };
}

function mapKakaoSuggestion(doc, query) {
  const roadAddress = String(doc.road_address_name || '');
  const address = String(doc.address_name || '');
  const placeName = String(doc.place_name || '');
  const lat = toNumber(doc.y);
  const lng = toNumber(doc.x);
  const main = roadAddress || address || placeName || query;
  return {
    query: main,
    main,
    placeName,
    roadAddress,
    address,
    category: String(doc.category_name || doc.category_group_name || ''),
    lat,
    lng
  };
}

async function getKakaoSuggestions(query) {
  const headers = { Authorization: `KakaoAK ${KAKAO_REST_API_KEY}` };
  const [keywordRes, addressRes] = await Promise.all([
    axios.get(`${KAKAO_BASE_URL}/search/keyword.json`, {
      params: { query, size: 7, sort: 'accuracy' },
      headers,
      timeout: 9000
    }),
    axios.get(`${KAKAO_BASE_URL}/search/address.json`, {
      params: { query, size: 5 },
      headers,
      timeout: 9000
    })
  ]);

  const merged = [];
  const seen = new Set();
  (keywordRes.data?.documents || []).forEach((doc) => {
    if (isExcludedPlaceDoc(doc)) return;
    const item = mapKakaoSuggestion(doc, query);
    const key = `${item.main}|${item.placeName}`;
    if (seen.has(key)) return;
    seen.add(key);
    merged.push(item);
  });
  (addressRes.data?.documents || []).forEach((doc) => {
    const main = String(doc.road_address?.address_name || doc.address_name || query);
    const address = String(doc.address_name || '');
    const roadAddress = String(doc.road_address?.address_name || '');
    const item = {
      query: main,
      main,
      placeName: '',
      roadAddress,
      address,
      category: '주소',
      lat: toNumber(doc.y),
      lng: toNumber(doc.x)
    };
    const key = `${item.main}|${item.address}`;
    if (seen.has(key)) return;
    seen.add(key);
    merged.push(item);
  });
  return merged.slice(0, 8);
}

app.get('/api/location/suggest', async (req, res) => {
  const q = String(req.query.q || '').trim();
  if (q.length < 2) {
    return res.json({ ok: true, items: [] });
  }

  try {
    if (KAKAO_REST_API_KEY) {
      const items = await getKakaoSuggestions(q);
      return res.json({ ok: true, provider: 'Kakao Local API', items });
    }
    return res.json({ ok: true, provider: 'none', items: [] });
  } catch (error) {
    return res.status(500).json({
      ok: false,
      error: error.response?.data?.message || error.message || '자동완성 조회 중 오류가 발생했습니다.'
    });
  }
});

app.get('/api/vworld/apart-price/hos', async (req, res) => {
  const pnu = String(req.query.pnu || '').trim();
  const dongNmRaw = String(req.query.dongNm || '').trim();
  const dongNm = normalizeDongToken(dongNmRaw);
  const stdrYear = toInteger(req.query.stdrYear) || new Date().getFullYear();

  if (!pnu || pnu.length < 10) {
    return res.status(400).json({ ok: false, error: 'pnu 파라미터가 필요합니다.' });
  }
  if (!dongNm) {
    return res.status(400).json({ ok: false, error: 'dongNm 파라미터가 필요합니다.' });
  }
  if (!VWORLD_APT_PRICE_KEY) {
    return res.status(500).json({ ok: false, error: 'VWORLD_APT_PRICE_KEY 누락' });
  }

  const result = await fetchVworldApartAttrAllPages(pnu, stdrYear, { dongNm }).catch((error) => ({
    ok: false,
    reason: error.response?.data?.apartHousingPrices?.resultMsg || error.message || 'VWorld 조회 실패',
    rows: []
  }));
  if (!result.ok) {
    return res.status(502).json({ ok: false, error: result.reason || 'VWorld 조회 실패' });
  }

  const rows = pickRepresentativeUnits(mapHoCandidatesFromVworld(result.rows))
    .filter((item) => normalizeDongToken(item.dongName) === dongNm)
    .sort((a, b) => {
      const fa = Number(a.floorNumber);
      const fb = Number(b.floorNumber);
      if (Number.isFinite(fa) && Number.isFinite(fb) && fa !== fb) return fa - fb;
      return String(a.hoName || '').localeCompare(String(b.hoName || ''), 'ko');
    });

  return res.json({
    ok: true,
    pnu,
    stdrYear,
    dongNm: dongNmRaw,
    count: rows.length,
    rows
  });
});

async function diagnoseLocation(query) {
  const out = {
    ok: true,
    query,
    env: {
      hasKakaoRestKey: Boolean(KAKAO_REST_API_KEY),
      hasKakaoMapJsKey: Boolean(KAKAO_MAP_JS_KEY),
      hasBuildingRegistryKey: Boolean(BUILDING_REGISTRY_SERVICE_KEY)
    },
    steps: {}
  };

  try {
    if (!KAKAO_REST_API_KEY) {
      out.steps.kakaoAddress = { ok: false, error: 'KAKAO_REST_API_KEY 누락' };
      out.ok = false;
      return out;
    }
    const normalized = await resolveAddressWithKakao(query);
    out.steps.kakaoAddress = {
      ok: true,
      provider: normalized.provider,
      building: normalized.building,
      parcel: normalized.parcel
    };

    try {
      const registry = await fetchBuildingRegistryDetails(normalized.parcel);
      out.steps.registry = {
        ok: registry.available,
        reason: registry.reason || '',
        summary: registry.summary || null,
        dongCount: registry.dongInfo?.length || 0,
        hoCount: registry.hoInfo?.length || 0
      };
      if (!registry.available) out.ok = false;
    } catch (e) {
      out.ok = false;
      out.steps.registry = {
        ok: false,
        error: e.response?.data?.response?.header?.resultMsg || e.message
      };
    }

    try {
      const mobility = await fetchMobilityAndRoad({
        lat: normalized.building.lat,
        lng: normalized.building.lng
      });
      out.steps.mobility = {
        ok: true,
        roadAccess: mobility.roadAccess,
        nearbyCount: mobility.nearbyItems?.length || 0,
        transit: mobility.transit
      };
    } catch (e) {
      out.ok = false;
      out.steps.mobility = {
        ok: false,
        error: e.response?.data?.message || e.message
      };
    }
  } catch (e) {
    out.ok = false;
    out.steps.kakaoAddress = {
      ok: false,
      error: e.response?.data?.msg || e.response?.data?.message || e.message
    };
  }

  return out;
}

app.get('/api/location/diagnose', async (req, res) => {
  const q = String(req.query.q || '').trim();
  if (!q) {
    return res.status(400).json({ ok: false, error: 'q(query) 파라미터가 필요합니다.' });
  }

  const result = await diagnoseLocation(q);
  return res.status(result.ok ? 200 : 500).json(result);
});

app.get('/api/apartment/py-types', async (req, res) => {
  const q = String(req.query.q || '').trim();
  if (!q) {
    return res.status(400).json({ ok: false, error: 'q(query) 파라미터가 필요합니다.' });
  }

  try {
    if (!KAKAO_REST_API_KEY) {
      return res.status(500).json({ ok: false, error: 'KAKAO_REST_API_KEY 누락' });
    }
    const normalized = await resolveAddressWithKakao(q);
    const [registry, vworld] = await Promise.all([
      fetchBuildingRegistryDetails(normalized.parcel),
      fetchVworldApartPriceUnits(normalized.parcel)
    ]);

    const fromVworld = pickRepresentativeUnits(Array.isArray(vworld?.hoCandidates) ? vworld.hoCandidates : []);
    const registryRows = (registry?.hoInfo || []).map((item) => ({
      ...item,
      source: 'registry'
    }));
    const sourceRows = fromVworld.length ? fromVworld : pickRepresentativeUnits(registryRows);
    const sourceType = fromVworld.length ? 'vworld' : 'registry-fallback';
    const pyeongTypes = buildPyeongTypeList(sourceRows, {
      areaBandStep: 0.01,
      minUnits: 1,
      includePriceStats: fromVworld.length > 0
    });

    return res.json({
      ok: true,
      query: q,
      source: sourceType,
      building: normalized.building,
      pnu: toPnuFromParcel(normalized.parcel),
      count: pyeongTypes.length,
      pyeongTypes
    });
  } catch (error) {
    return res.status(500).json({
      ok: false,
      error: error.response?.data?.message || error.message || '평형 타입 조회 실패'
    });
  }
});

app.get('/api/location/search', async (req, res) => {
  const q = String(req.query.q || '').trim();
  if (!q) {
    return res.status(400).json({
      ok: false,
      error: 'q(query) 파라미터가 필요합니다.'
    });
  }

  try {
    let providerResult;
    let mobility = null;
    let registry = null;
    let vworldAptPrice = null;
    let housingPipeline = null;
    let registryLinkage = null;

    if (KAKAO_REST_API_KEY) {
      const normalized = await resolveAddressWithKakao(q);
      providerResult = {
        provider: normalized.provider,
        building: normalized.building
      };
      const center = { lat: normalized.building.lat, lng: normalized.building.lng };
      const [registryResult, mobilityResult, rebAptId, vworldResult] = await Promise.all([
        fetchBuildingRegistryDetails(normalized.parcel),
        fetchMobilityAndRoad(center).catch(() => null),
        fetchRebAptIdDetails(normalized).catch((error) => ({
          available: false,
          reason: `REB 단지식별 조회 실패: ${error.response?.data?.msg || error.message}`,
          complex: null,
          dongInfo: []
        })),
        fetchVworldApartPriceUnits(normalized.parcel).catch((error) => ({
          available: false,
          reason: `VWorld 공동주택가격 조회 실패: ${error.response?.data?.apartHousingPrices?.resultMsg || error.message}`,
          year: null,
          pnu: null,
          hoCandidates: []
        }))
      ]);
      const housingResult = await fetchHousingUnitPipeline(normalized, registryResult, rebAptId, vworldResult);
      registry = registryResult;
      mobility = mobilityResult;
      housingPipeline = housingResult;
      vworldAptPrice = vworldResult;
      providerResult.rebAptId = rebAptId;
      registryLinkage = buildRegistryLinkageInfo(normalized, registryResult, housingResult);
    } else {
      const osmResult = await searchWithOsm(q);
      providerResult = osmResult;
      const center = { lat: osmResult.building.lat, lng: osmResult.building.lng };
      mobility = await fetchMobilityAndRoad(center).catch(() => null);
      registry = {
        available: false,
        reason: 'KAKAO_REST_API_KEY 및 BUILDING_REGISTRY_SERVICE_KEY 설정 시 건축물대장 상세 제공',
        summary: null,
        dongInfo: [],
        hoInfo: []
      };
      vworldAptPrice = {
        available: false,
        reason: 'KAKAO_REST_API_KEY 설정 시 VWorld 공동주택가격 연동을 사용할 수 있습니다.',
        year: null,
        pnu: null,
        hoCandidates: []
      };
      housingPipeline = {
        source: 'none',
        hoCandidates: [],
        dongCandidates: [],
        note: 'KAKAO_REST_API_KEY 설정 시 동/호/평형 보강 파이프라인을 사용할 수 있습니다.'
      };
      providerResult.rebAptId = {
        available: false,
        reason: 'KAKAO_REST_API_KEY 설정 시 REB 단지/동 보강을 사용할 수 있습니다.',
        complex: null,
        dongInfo: []
      };
      registryLinkage = {
        usableForRegistryWorkflow: false,
        sourceType: 'none',
        confidence: 'none',
        note: '카카오 주소 정규화/필지코드가 없어 등기 연계용 키를 만들 수 없습니다.',
        parcelKey: null
      };
    }

    const summary = registry?.summary || {};
    providerResult.building.use = summary.mainPurpose && summary.mainPurpose !== '-'
      ? summary.mainPurpose
      : providerResult.building.use;

    const fromVworld = pickRepresentativeUnits(Array.isArray(vworldAptPrice?.hoCandidates) ? vworldAptPrice.hoCandidates : []);
    const sourceRowsForTypes = fromVworld.length
      ? fromVworld
      : pickRepresentativeUnits((registry?.hoInfo || []).map((item) => ({ ...item, source: 'registry' })));
    const pyeongTypes = buildPyeongTypeList(sourceRowsForTypes, {
      areaBandStep: 0.01,
      minUnits: 1,
      includePriceStats: fromVworld.length > 0
    });

    return res.json({
      ok: true,
      provider: providerResult.provider,
      building: providerResult.building,
      registry,
      rebAptId: providerResult.rebAptId || null,
      vworldAptPrice,
      pyeongTypes,
      housingPipeline,
      registryLinkage,
      roadAccess: mobility?.roadAccess || null,
      transit: mobility?.transit || null,
      nearbyItems: mobility?.nearbyItems || providerResult.nearbyItems || []
    });
  } catch (error) {
    return res.status(500).json({
      ok: false,
      error: error.response?.data?.message || error.message || '주소 검색 중 오류가 발생했습니다.',
      detail: error.response?.data || null
    });
  }
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

async function start() {
  await ratesBatchService.init();
  app.listen(port, () => {
    console.log(`Rates dashboard running on http://localhost:${port}`);
  });
}

start().catch((error) => {
  console.error('Failed to start app:', error.message);
  process.exit(1);
});
